<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
        <!-- /////// Vamos fazer um form Simples -->        
        <form name="Usuario" action="crud.php">            
            <input type="text" name="NOMEUSU" value="Joao" size="20" />  
            <input type="number" name="IDADEUSU" value="30" size="10" />
            <input type="submit" value="INSERIR" name="enviar" />
        </form>
    </body>
</html>
