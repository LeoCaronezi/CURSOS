<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
        <form name="Usuario" action="CRUDProduto.php">            
            <input type="text" name="NOMEPROD" value="Geladeira" size="30" />  
            <input type="number" name="CODPROD" value="10" size="10" />
            <input type="number" name="QDEPROD" value="5" size="10" />
            <input type="number" name="PRECOPROD" value="1000" size="10" />
            <input type="submit" value="INSERIR" name="enviar" />
        </form>        
    </body>
</html>
