<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        echo "Meu primeiro Hello World PHP!";
        ?>
    </body>
</html>
