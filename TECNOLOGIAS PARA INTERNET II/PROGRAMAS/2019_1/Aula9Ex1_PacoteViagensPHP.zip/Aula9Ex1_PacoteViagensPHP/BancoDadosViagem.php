<?php
  function construirViagem($req){
         $nome    = $req['PACOTE'];
         $sai     = $req['SAIDA'];
         $datasai = $req['DATASAIDA'];
   
         $che     = $req['CHEGADA'];
         $datache = $req['DATACHEGADA'];   

         $vol     = $req['VOLTA'];
         $datavol = $req['DATAVOLTA'];  
         
         $dias     = $req['DIASHOTEL'];     
         
         $preco   = $req['PRECO'];         
         $obj = new Viagem($nome, $sai, $datasai, $che, $datache, $vol, $datavol, $dias, $preco);
         return $obj;
    }
    function conectarBanco(){
        $dsn = "mysql:dbname=PACVIAGEMDB;host=localhost:3306";
        $user = 'root';
        $pass = '';
        try{
            $dbh = new PDO($dsn,$user,$pass);            
            echo "Conexao bem sucedida";
        } catch (Exception $ex) {
            echo "Problemas na conexao " . $ex->getMessage();

        }
        return $dbh;
    }
    function inserirBanco($dbh,$pacote){
        $sql = "INSERT INTO VIAGEM_TB(PACOTE,SAIDA,DATASAIDA,CHEGADA,DATACHEGADA,VOLTA,DATAVOLTA,DIASHOTEL,PRECO) "
             . "VALUES('" . $pacote->getNomeViagem()  .   "',"
                    . "'" . $pacote->getCodSaida()   .    "',"
                    . "'" . $pacote->getDataSaida()   .   "',"
                
                    . "'" . $pacote->getCodChegada()   .    "',"
                    . "'" . $pacote->getDataChegada()   .   "',"
                
                    . "'" . $pacote->getCodVolta()    .   "',"
                    . "'" . $pacote->getDataVolta()   .   "',"
                
                    .       $pacote->getDiasHotel()   .    ","          
                
                    .        $pacote->getPrecoViagem() .     ")";
        echo "SQL: " . $sql;
        $dbh->exec($sql);        
    }
    function lerBanco($dbh){
        $carrinho = [];
        $sql = "SELECT PACOTE,SAIDA,DATASAIDA,CHEGADA,DATACHEGADA,VOLTA,DATAVOLTA,DIASHOTEL,PRECO "
             . "FROM VIAGEM_TB";
     foreach ($dbh->query($sql) as $reg) {               
         $obj = construirViagem($req);
         $carrinho[] = $obj;                  
     }
     return $carrinho;           
    }
    function apagaBanco($dbh){
            $sql ="DELETE "
            . "FROM VIAGEM_TB ";
        $dbh->exec($sql);            
        echo "SQL: " . $sql;      
    }
    function removeBanco($dbh,$pacote) {
        $sql ="DELETE "
            . "FROM VIABEM_TB "
            . "WHERE PACOTE = '" . $pacote->getNomeViagem() . "'";
        $dbh->exec($sql);            
        echo "SQL: " . $sql;        
    }
    function alterabanco($dbh,$peca){
        $sql = "UPDATE VIAGEM_TB "
                     . "SET "
                     .    "TAMANHO    = '" . $pacote->getNomeViagem() .   "',"
                     .    "SAIDA      = '" . $pacote->getCodSaida()   .   "',"     
                     .    "DATASAIDA  = '" . $pacote->getDataSaida() .  "',"
                 
                    .     "CHEGADA    =  '" . $pacote->getCodChegada()  .    "',"
                    .     "DATACHEGADA = '" . $pacote->getDataChegada() .   "',"
                
                    .     "VOLTA       = '" . $pacote->getCodVolta()    .   "',"
                    .     "DATAVOLTA   = '" . $pacote->getDataVolta()   .   "',"
                
                    .       $pacote->getDiasHotel()   .    ","          
                
                    .        $pacote->getPrecoViagem() 
                
                    . " WHERE PACOTE = '" . $pacote->getNomeViagem() . "'";
        $dbh->exec($sql);            
        echo "SQL: " . $sql; 
    }
    function lerBancoPreco($dbh,$pacote){
        $carrinho = [];
        $sql = "SELECT NOME,TAMANHO,PRECO,QUANTIDADE "
             . "FROM VESTUARIO_TB "
             . "WHERE PRECO > " . $peca->getPrecoVestuario();
        echo "SQL: " . $sql;         
     foreach ($dbh->query($sql) as $reg) {
         
         $nome  = $reg['NOME'];
         $tam   = $reg['TAMANHO'];
         $preco = $reg['PRECO'];
         $qde   = $reg['QUANTIDADE'];         
         $obj = new Vestuario($nome, $tam, $preco, $qde);
         $carrinho[] = $obj;                  
     }
     return $carrinho;           
    }

?>
