<?php

    include './Viagem.php';
    function mostraCarrinho($carrinho){
      echo "<table border=1>";
       echo "<tbody>";
      echo "<tr>"
            . "<td>Pacote</td>"
            . "<td>Cod.S</td>"              
            . "<td>Data.S</td>"
             . "<td>Cod.C</td>"              
            . "<td>Data.C</td>"
            . "<td>Cod.V</td>"              
            . "<td>Data.V</td>"              
            . "<td>Dias H.</td>"                       
            . "<td>Preco</td>"                                 
         . "</tr>";  
        foreach ($carrinho as $pacote) {
            $pacote->mostraLinhaCarrinho();               
        }
       echo "<tbody>";        
      echo "</table>";        
    }
?>