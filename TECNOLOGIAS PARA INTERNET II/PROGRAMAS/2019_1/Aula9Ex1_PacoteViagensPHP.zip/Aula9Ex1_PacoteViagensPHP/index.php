<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
           include './BancoDadosViagem.php';
           include './TabelaCompras.php';
           $carrinhoCompras = [];
           $dbh = conectarBanco();
           $comando = $_GET['COMANDO'];
           if ($comando == "Listar Pacotes Comprados"){
               $carrinhoCompras = lerBanco($dbh);           
               mostraCarrinho($carrinhoCompras);        
           }
           if ($comando == "Comprar Pacote"){
               $pacote = construirViagem($_GET);               
               inserirBanco($dbh, $pacote);                                              
               echo "<H1> Pacote Inserido </H1>";
           }
           if ($comando == "Remover Pacote"){
               $pacote = construirViagem($_GET);               
               removeBanco($dbh, $pacote);
               echo "<H1> Pacote Removida </H1>";
           }
           if ($comando == "Alterar Pacote"){
               $pacote = construirViagem($_GET);               
               alterabanco($dbh, $pacote);
               echo "<H1> Pacote Alterada </H1>";
           }           
           if ($comando == "Filtrar Pacote"){
               $pacote = construirPacote($_GET);               
               $carrinhoCompras = lerBancoPreco($dbh,$pacote);           
               mostraCarrinho($carrinhoCompras);        
           }  
        ?>
        <form action="http://localhost:8383/Aula9Ex1_PACOTE_VIAGENS/index.html">
            
            <input type="submit" value="Comprar Mais" />
            
        </form>
        
        <form action="http://localhost:8383/Aula9Ex1_PACOTE_VIAGENS/index.html">
            
            <input type="submit" value="Filtrar Pacote" />
            
        </form>    
        
    </body>
</html>
