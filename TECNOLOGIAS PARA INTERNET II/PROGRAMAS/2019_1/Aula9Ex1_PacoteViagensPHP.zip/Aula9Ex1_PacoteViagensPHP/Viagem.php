<?php

class Viagem {
    private $nomeViagem  = "";
    private $codSaida    = "GIG";
    private $dataSaida   = "00/00/0000";
    private $codChegada  = "LAX";
    private $dataChegada  = "00/00/0000";
    private $codVolta     = "GIG";
    private $dataVolta    = "00/00/0000";
    private $diasHotel    = 1;
    private $precoViagem  = 1000;
    
    function __construct($nomeViagem, $codSaida, $dataSaida, $codChegada, $dataChegada, $codVolta, $dataVolta, $diasHotel, $precoViagem) {
        $this->nomeViagem = $nomeViagem;
        $this->codSaida = $codSaida;
        $this->dataSaida = $dataSaida;
        $this->codChegada = $codChegada;
        $this->dataChegada = $dataChegada;
        $this->codVolta = $codVolta;
        $this->dataVolta = $dataVolta;
        $this->diasHotel = $diasHotel;
        $this->precoViagem = $precoViagem;
    }

    function getNomeViagem() {
        return $this->nomeViagem;
    }

    function getCodSaida() {
        return $this->codSaida;
    }

    function getDataSaida() {
        return $this->dataSaida;
    }

    function getCodChegada() {
        return $this->codChegada;
    }

    function getDataChegada() {
        return $this->dataChegada;
    }

    function getCodVolta() {
        return $this->codVolta;
    }

    function getDataVolta() {
        return $this->dataVolta;
    }

    function getDiasHotel() {
        return $this->diasHotel;
    }

    function getPrecoViagem() {
        return $this->precoViagem;
    }    
    function mostraLinhaCarrinho(){
        echo "<tr>";
          echo "<td>" . $this->nomeViagem . "</td>";
          echo "<td>" . $this->codSaida . "</td>";
          echo "<td>" . $this->dataSaida . "</td>";
   
          echo "<td>" . $this->codChegada . "</td>";
          echo "<td>" . $this->dataChegada . "</td>";

          echo "<td>" . $this->codVolta . "</td>";
          echo "<td>" . $this->dataVolta . "</td>";          
          
          echo "<td>" . $this->diasHotel . "</td>";
          
          echo "<td>" . ($this->precoViagem) . "</td>";        
        echo "</tr>";
    }
    

    
    
    
    
}
