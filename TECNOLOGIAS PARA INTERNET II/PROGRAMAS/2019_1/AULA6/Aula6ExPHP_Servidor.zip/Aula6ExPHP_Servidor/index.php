<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $NomeAluno  = $_GET["ALUNO"];
            $MediaAluno = $_GET["MEDIA"];
            $W1         = $_GET["W1"];
            $W2         = $_GET["W2"];
            $W3         = $_GET["W3"];
            $W4         = $_GET["W4"];
            $W5         = $_GET["W5"];
            
            $MediaTrabalhos = ($W1 + $W2 + $W3 + $W4 + $W5)/5;  
            $MediaGeral = ($MediaAluno + $MediaTrabalhos)/2;
            echo "ALUNO:"           . $NomeAluno       . "</br>" ;
            echo "Media Provas:"    . $MediaAluno      . "</br>" ;
            echo "Media Trabalhos:" . $MediaTrabalhos  . "</br>";
            echo "Media Geral:"     . $MediaGeral      . "</br>";
                    
            
        ?>
    </body>
</html>
