package aula4ex1produtos;

public class Produto {
    private String nomeProduto;
    private double precoProduto;
    private int    qdeProduto;

    public Produto(String nomeProduto, double precoProduto, int qdeProduto) {
        this.nomeProduto = nomeProduto;
        this.precoProduto = precoProduto;
        this.qdeProduto = qdeProduto;
    }
    public double calculaTotal(){
        return precoProduto * qdeProduto;
    }
    
    public String getNomeProduto() {
        return nomeProduto;
    }

    public double getPrecoProduto() {
        return precoProduto;
    }

    public int getQdeProduto() {
        return qdeProduto;
    }

    
    
    
}
