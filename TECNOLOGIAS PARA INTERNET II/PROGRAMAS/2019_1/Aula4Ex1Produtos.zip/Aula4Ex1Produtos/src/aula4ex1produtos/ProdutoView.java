
package aula4ex1produtos;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
   


public class ProdutoView {
    private JFrame produtoJFrame;
    
    private JLabel      produtoJLabel;
    private JTextField  produtoJTextField;
    
    private JLabel      precoJLabel;
    private JTextField  precoJTextField;
    
    private JLabel      qdeJLabel;
    private JTextField  qdeJTextField;
    
    private JLabel      totalJLabel;
    private JLabel      totalCalculadoJLabel;
    
    private JButton     inserirJButton;
    private JButton     listarJButton;
    
    private JLabel      listaProdutosJLabel;
    
    public ProdutoView(){
        produtoJFrame = new JFrame("Lista de Produtos");
        produtoJFrame.setSize(300, 400);
        produtoJFrame.setLayout(new FlowLayout());
        produtoJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        produtoJLabel     = new JLabel("Produto: ");
        produtoJTextField  = new JTextField(10);
        
        precoJLabel        = new JLabel("Preço R$:");
        precoJTextField    = new JTextField(4);
        
        qdeJLabel          = new JLabel("Quantidade:");
        qdeJTextField      = new JTextField(2);
        
        totalJLabel        = new JLabel("TOTAL R$:");
        totalCalculadoJLabel = new JLabel("____");
        
        inserirJButton    = new JButton("Inserir Produto");
        listarJButton     = new JButton("Listar Produtos");
        
        listaProdutosJLabel = new JLabel("Lista: ");
        produtoJFrame.add(produtoJLabel);
        produtoJFrame.add(produtoJTextField);        
        produtoJFrame.add(precoJLabel);
        produtoJFrame.add(precoJTextField);        
        produtoJFrame.add(qdeJLabel);
        produtoJFrame.add(qdeJTextField);        
        produtoJFrame.add(totalJLabel);
        produtoJFrame.add(totalCalculadoJLabel);        
        produtoJFrame.add(inserirJButton);
        produtoJFrame.add(listarJButton);        
        produtoJFrame.add(listaProdutosJLabel);        
        produtoJFrame.setVisible(true);        
    }
    
    public Produto obterProduto(){
        String nome  = produtoJTextField.getText();
        double preco = Double.parseDouble(precoJTextField.getText());
        int    qde   = Integer.parseInt(qdeJTextField.getText());
        
        Produto p = new Produto(nome, preco, qde);
        return p;
    }
    public void mostrarProduto(Produto p){
        produtoJTextField.setText(p.getNomeProduto());
        precoJTextField.setText(""+p.getPrecoProduto());
        qdeJTextField.setText(""+p.getQdeProduto());
        totalCalculadoJLabel.setText("" + p.calculaTotal());
    }
    public void mostraListaProdutos(String lista){
        
    }
    public void adicionarInserirListener(ActionListener al){
        inserirJButton.addActionListener(al);
    }
    public void adicionarListarListener(ActionListener al){
        listarJButton.addActionListener(al);
    }
    
}
