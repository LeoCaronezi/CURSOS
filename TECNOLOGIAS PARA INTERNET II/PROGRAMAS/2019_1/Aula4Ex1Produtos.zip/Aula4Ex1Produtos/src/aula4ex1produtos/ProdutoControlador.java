
package aula4ex1produtos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ProdutoControlador {
    private ProdutoView produtoView;
    private ArrayList<Produto> listaProduto;
    
    
    private class InserirListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent e) {
           /// Codigo que insere o novo produto na lista 
            Produto p = produtoView.obterProduto();
            listaProduto.add(p);
            produtoView.mostrarProduto(p);                       
        }         
    }
    
    private class ListarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
        //// Codigo para mostrar a lista
        }        
    }
    void iniciarControlador(){        
        produtoView = new ProdutoView();
        listaProduto = new ArrayList<Produto>();
        produtoView.adicionarInserirListener(new InserirListener());
        produtoView.adicionarListarListener(new ListarListener());
        
    }
    
}
