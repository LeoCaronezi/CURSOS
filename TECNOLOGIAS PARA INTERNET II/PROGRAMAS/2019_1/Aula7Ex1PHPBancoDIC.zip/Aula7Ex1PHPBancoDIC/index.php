<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $dsn = 'mysql:dbname=tradutor;host=localhost:3306';
            $user = "root";
            $password = "";
            try {
                $dbh = new PDO($dsn,$user,$password);   
                echo "Conexao bem sucedida";
                
                $ling1 = $_GET["LINGUAGEM1"];
                $ling2 = $_GET["LINGUAGEM2"];
                $pal1 =  $_GET["PALAVRA1"];
                $pal2 =  $_GET["PALAVRA2"];
                $comanado = $_GET["COMANDO"];
                
                $sql = "INSERT INTO DICIONARIO (LINGUAGEM1, LINGUAGEM2, "
                                             . "PALAVRA1, PALAVRA2) "
                        . "VALUES( '$ling1','$ling2','$pal1','$pal2');";
                
                echo " O comando digitado foi: " . $comanado;
                $dbh->exec($sql);
                
                $sql = "SELECT LINGUAGEM1, PALAVRA1,"
                        .     "LINGUAGEM2, PALAVRA2 "
                     . "FROM DICIONARIO;";             
                $resultado = $dbh->query($sql);
                
                print "<table border=3>";
                foreach ($resultado as $row) {
                    print "<TR> "
                            . "<TD>" .$row["LINGUAGEM1"] . "</TD>"
                            . "<TD>" .$row["PALAVRA1"] . "</TD>"
                            . "<TD>" .$row["LINGUAGEM2"] . "</TD>"
                            . "<TD>" .$row["PALAVRA2"] . "</TD>"
                            . "</TR>";
                }
                print "</table>";
                                
            } catch (Exception $exc) {
                echo "Erro no banco" . $exc->getTraceAsString();
            }

        ?>
    </body>
</html>
