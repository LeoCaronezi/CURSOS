/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notasalunoarray;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class NotasAlunoArray {

    public static double mediaNota(double av1,double av2, double av3){
        return (av1+av2+av3)/3;
    }
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Diga o numero de alunos");
        int nrAlunos = input.nextInt();
        
        double[] aV1 = new double[nrAlunos];  
        double[] aV2 = new double[nrAlunos];
        double[] aV3 = new double[nrAlunos];
        for(int i=0; i <nrAlunos ; i++){
            System.out.println("Aluno " + (i+1));
            System.out.println("Entre nota da AV1:"); aV1[i] = input.nextDouble();
            System.out.println("Entre nota da AV2:"); aV2[i] = input.nextDouble();
            System.out.println("Entre nota da AV3:"); aV3[i] = input.nextDouble();
            double mediaFinal = mediaNota(aV1[i],aV2[i],aV3[i]);
            System.out.println("Media: "+ mediaFinal);
        }
        
    }

        
        
    
}
