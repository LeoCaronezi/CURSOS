/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5ex2;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class JanelaProduto {
   private Produto produtoJanela;

    public JanelaProduto() {
    }
    
   
   public JanelaProduto(String nome, 
                         double preco,
                         double custo,
                         int quantidade){
        produtoJanela = new Produto(nome,
                preco, 
                custo,
                quantidade);      
    }
    public JanelaProduto(Produto p){
        produtoJanela = p;
        
        
    }
            
    public void mostraProduto (){
       System.out.println(produtoJanela.modoTexto());
    }    
    public void mostraProduto (Produto p){
        produtoJanela = p;
        mostraProduto();      
    }    
    
    public Produto leProduto(){
        String nome;
        double preco;
        double custo;
        int quantidade;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite o nome do produto:");
          nome  = entrada.next();
        System.out.println("Digite o preco do produto:");
          preco  = entrada.nextDouble();   
        System.out.println("Digite o custo do produto:");
          custo  = entrada.nextDouble();        
        System.out.println("Digite a quantidade do produto: (0)para Cancelar");
          quantidade  = entrada.nextInt();
        if(quantidade !=0 ){
             Produto p = new Produto(nome, preco, custo, quantidade);
             return p;    
        }else{
            return null;
        }
              
    }
    
}
