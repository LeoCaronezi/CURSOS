/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5ex2;

/**
 *
 * @author aluno
 */
public class Produto {
     
    private String nomeProduto;
    private double precoProduto;
    private double custoProduto;
    private int quantidadeProduto;
    
     public Produto(String nome, 
                         double preco,
                         double custo,
                         int quantidade){
        this.nomeProduto = nome;
        this.precoProduto = preco;
        this.custoProduto = custo;
        this.quantidadeProduto = quantidade;        
    }
     public String modoTexto(){
         return("Produto:" + nomeProduto + " Preco R$" + precoProduto +
                 " Custo" + custoProduto + " Quantidade" + quantidadeProduto);
         
     }
             
}
