/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5ex2;

/**
 *
 * @author aluno
 */
public class Aula5ex2 {

        private static Produto[] listaProdutos = new Produto[1000];
        private static int nrProdutos = 0;
        private static JanelaProduto viewProduto = new JanelaProduto();

    public static void main(String[] args) {
               
        Produto p = viewProduto.leProduto();
        while(p!=null){
          listaProdutos[nrProdutos] = p;
          nrProdutos++;
          p = viewProduto.leProduto();
        }
        
        for(int i=0 ; i < nrProdutos ; i++){
            viewProduto.mostraProduto(listaProdutos[i]);
        }
        
        
                
        
        //SEGUEEEEEEEEEE LAAAAAAAAAAAAAAAAAAA NO TWITTEEEEEEEEEEEEEEEEEE
        
        // TODO code application logic here
    }
    
}
