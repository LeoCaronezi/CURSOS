/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoaarquivoapplication;

/**
 *
 * @author aluno
 */
public class PessoaArquivoApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Criar objeto da classe pessoa
        Pessoa p1 = new Pessoa("Batman",125,
                               "C:\\Users\\Public\\Documents\\ArqEmpresa.txt");
        Funcionario p2 = new Funcionario("Ras'al Gull",350,
                               "C:\\Users\\Public\\Documents\\ArqEmpresa.txt",
                               "MAT001",200.00);

               
        p1.savePessoa();
        p2.savePessoa();
      
              
        
    }
    
}
