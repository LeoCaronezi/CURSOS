/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoaarquivoapplication;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aluno
 */
public class Funcionario extends Pessoa{
    private double salarioFuncHora = 0.0;
    private String matFuncionario = "000";
    private int horasTrabalhadas = 0;

    public Funcionario(String matricula,double salariohora){
        matFuncionario = matricula;
        salariohora = salariohora;      
    }

    public Funcionario(String nome,int idade,String arq,
                       String matricula,double salariohora){
        super(nome,idade,arq);
        matFuncionario = matricula;
        salariohora = salariohora;      
    }
    
    public void savePessoa(){
     super.savePessoa();
        
     try{
        boolean noFinal = true;
        FileWriter fw = new FileWriter(nomeArq,noFinal);
            String linha = "Matricula:" + matFuncionario + "  Salario Hora:"+salarioFuncHora +"\r\n";
            fw.write(linha);
        fw.close();          
        
      }catch(IOException ex){
          System.out.println("Erro de arquivo "+ex);
      }
        
        
        
        
    }
    
    
    
}
