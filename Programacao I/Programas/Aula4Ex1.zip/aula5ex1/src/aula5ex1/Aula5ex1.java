/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5ex1;

/**
 *
 * @author aluno
 */
public class Aula5ex1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        JanelaProduto v = new JanelaProduto("jilo", 3.99, 
                0.10, 500);
        v.mostraProduto();
        
        //SEGUEEEEEEEEEE LAAAAAAAAAAAAAAAAAAA NO TWITTEEEEEEEEEEEEEEEEEE
        
        // TODO code application logic here
    }
    
}
