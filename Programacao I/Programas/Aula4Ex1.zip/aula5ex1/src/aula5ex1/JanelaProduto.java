/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5ex1;

/**
 *
 * @author aluno
 */
public class JanelaProduto {
   private Produto produtoJanela;
    
    public JanelaProduto(String nome, 
                         double preco,
                         double custo,
                         int quantidade){
        produtoJanela = new Produto(nome,
                preco, 
                custo,
                quantidade);      
    }
    public JanelaProduto(){
        
        
    }
            
    public void mostraProduto (){
       System.out.println(produtoJanela.modoTexto());
        
                
        
        
    }   
    
    
    
    
    
    
    
    
    
}
