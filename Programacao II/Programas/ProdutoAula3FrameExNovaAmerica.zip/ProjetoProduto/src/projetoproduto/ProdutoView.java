/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoproduto;

import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author alunoti
 */
public class ProdutoView {
    //atributos
    private JFrame principalJFrame;
    private JLabel nomeProdutoJLabel;
    private JTextField nomeProdutoJTextField;
    private JLabel quantidadeProdutoJLabel;
    private JTextField quantidadeProdutoJTextField;
    private JLabel precoProdutoJLabel;
    private JTextField precoProdutoJTextField;
    
    private JLabel totalProdutoJLabel;
    
    public ProdutoView(){
        principalJFrame = new JFrame("Informacao Produto");
        principalJFrame.setSize(350, 300);
        principalJFrame.setLayout(new FlowLayout());
        principalJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        nomeProdutoJLabel = new JLabel("Produto:");
        nomeProdutoJTextField = new JTextField(20);
        
        quantidadeProdutoJLabel = new JLabel("Quantidade:");
        quantidadeProdutoJTextField = new JTextField(4);
        
        precoProdutoJLabel = new JLabel("Preco:");
        precoProdutoJTextField = new JTextField(6);
        
        totalProdutoJLabel = new JLabel("");
        
        principalJFrame.add(nomeProdutoJLabel);
        principalJFrame.add(nomeProdutoJTextField);
        principalJFrame.add(quantidadeProdutoJLabel);
        principalJFrame.add(quantidadeProdutoJTextField);
        principalJFrame.add(precoProdutoJLabel);
        principalJFrame.add(precoProdutoJTextField);
        principalJFrame.add(totalProdutoJLabel);
        
        
        principalJFrame.setVisible(true);
    }
    
    public void inserirDadosProduto(String nome,int qde,double preco,double total){
          nomeProdutoJTextField.setText(nome);
          quantidadeProdutoJTextField.setText(Integer.toString(qde));
          precoProdutoJTextField.setText(Double.toString(preco));
          
          totalProdutoJLabel.setText("Total = "+ total);
    }
    
    
    
}
