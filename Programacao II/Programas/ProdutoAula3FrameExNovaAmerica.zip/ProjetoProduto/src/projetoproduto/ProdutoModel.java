/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoproduto;

/**
 *
 * @author alunoti
 */
public class ProdutoModel {
    //Atritbutos
    private String nomeProduto;
    private int    quantidadeProduto;
    private double precoProduto;

    public ProdutoModel(String nomeProduto, int quantidadeProduto, double precoProduto) {
        this.nomeProduto = nomeProduto;
        this.quantidadeProduto = quantidadeProduto;
        this.precoProduto = precoProduto;
    }

    public ProdutoModel(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }
    public double calculaTotal(){
        double total = quantidadeProduto * precoProduto;
        total  = total * 1.5;
        return total;
    }
            
    public String getNomeProduto() {
        return nomeProduto;
    }

    public int getQuantidadeProduto() {
        return quantidadeProduto;
    }

    public double getPrecoProduto() {
        return precoProduto;
    }
    
    
    
    
    
    
}
