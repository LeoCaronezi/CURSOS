/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoproduto;

/**
 *
 * @author alunoti
 */
public class ProdutoControler {
    
    public void executarOqueVoceFaz(){
        
        ProdutoModel pm = new ProdutoModel("Pizza", 10, 1);
        
        ProdutoView pv = new ProdutoView();
        
        pv.inserirDadosProduto(pm.getNomeProduto(),
                               pm.getQuantidadeProduto(), 
                               pm.getPrecoProduto(),
                               pm.calculaTotal());
        
        
        
    }
    
}
