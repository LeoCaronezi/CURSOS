/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula4exemplo1;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.xml.bind.Marshaller;


public class ViewContador {
   private JFrame contadorJFrame;
   private JLabel resultadoJlabel;
   private JButton contaJbutton;

    public ViewContador() {
        
        contadorJFrame=new JFrame("Juju");
        contadorJFrame.setSize(100,200);
        contadorJFrame.setLayout(new FlowLayout());
        
        resultadoJlabel=new JLabel("NR: 0");
        
        contaJbutton=new JButton("Linda");
        
        contadorJFrame.add(contaJbutton);
        contadorJFrame.add(resultadoJlabel);
        
        contadorJFrame.setVisible(true);
    }
   
   public void adicionarManipuladorEventos(ActionListener l){
       contaJbutton.addActionListener(l);
       
   }
   public void atualizaContador(int a){
       resultadoJlabel.setText("NR: " + a);
       
   }
}

