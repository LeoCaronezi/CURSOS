/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula4exemplo1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author aluno
 */
public class Controlador {
    private ViewContadorJFrame viewContador;
    private Contador contador;
    
    public void executar(){
        
       viewContador=new ViewContadorJFrame();
       contador=new Contador(0);
       
       ContadorManipulador x=new ContadorManipulador();
       
       viewContador.adicionarManipuladorEventos(x);
       viewContador.setVisible(true);
       
       
        
    }
    public class ContadorManipulador implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
           int a=contador.getValorCont();
           a++;
           contador.setValorCont(a);
           
           viewContador.atualizaContador(a);
           
           
        }
        
    }
}
