/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula4exemplo1;

/**
 *
 * @author aluno
 */
public class Contador {
    private int valorCont;

    public Contador(int valorCont) {
        this.valorCont = valorCont;
    }

    public int getValorCont() {
        return valorCont;
    }

    public void setValorCont(int valorCont) {
        this.valorCont = valorCont;
    }
    
    
}
