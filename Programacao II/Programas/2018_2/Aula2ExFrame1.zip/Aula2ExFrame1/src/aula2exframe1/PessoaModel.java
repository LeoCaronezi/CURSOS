/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula2exframe1;

/**
 *
 * @author aluno
 */
public class PessoaModel {
    private String nomePessoa;

    public PessoaModel(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }

    public String getNomePessoa() {
        return nomePessoa;
    }
    
    
    
}
