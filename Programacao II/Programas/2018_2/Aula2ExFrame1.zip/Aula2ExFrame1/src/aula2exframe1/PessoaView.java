/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula2exframe1;


import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class PessoaView {
    //1-Declarar Objetos Visuais
    private JFrame      pessoaJFrame;    
    private JLabel      nomeJLabel;
    private JTextField  nomeJTextField;    
    //2 - Construtor
    public PessoaView(){
        //2.1 Criar o JFrame
        pessoaJFrame = new JFrame("Aula2 Ex1");
        pessoaJFrame.setSize(200, 300);
        
        // COLOCAR SEMPRE LAYOUT DEFAULT
        pessoaJFrame.setLayout(new FlowLayout());
        // Fechar o programa junto com a janela
        pessoaJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        //2.2 Criar Objetos do Frame
        nomeJLabel = new JLabel("Nome da Pessoa:");
        nomeJTextField = new JTextField(30);
        
        //2.3 Adicionar Objetos no Frame
        pessoaJFrame.add(nomeJLabel);
        pessoaJFrame.add(nomeJTextField);
        
        //2.4 "Faça-se a LUZ!!!        
        pessoaJFrame.setVisible(true);
    }
    
    public void showPessoa(PessoaModel p){
        nomeJTextField.setText(p.getNomePessoa());
    }
    
    
    
}
