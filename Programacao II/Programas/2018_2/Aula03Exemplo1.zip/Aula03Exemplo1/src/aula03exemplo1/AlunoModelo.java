package aula03exemplo1;

/**
 *
 * @author alunoti
 */
public class AlunoModelo {
    
    //1.1 Declarar os abributos 
    private String alunoNome;//Atributo onde será guardado o nome do aluno
    private double av1Aluno;//Atributo onde será guardado a av1 do aluno
    private double av2Aluno;//Atributo onde será guardado a av2 do aluno
    private double av3Aluno;//Atributo onde será guardado a av3 do aluno
    private double mediaAluno;//Atributo onde será guardado a media do aluno

    //1.2 - Metodo Construtor padrao
    public AlunoModelo(String alunoNome, double av1Aluno, double av2Aluno, 
            double av3Aluno) {
        this.alunoNome = alunoNome;
        this.av1Aluno = av1Aluno;
        this.av2Aluno = av2Aluno;
        this.av3Aluno = av3Aluno;
    }
    
    //1.3 - Calcula a media
    public double calculaMedia(){
        return (av1Aluno+av2Aluno+av3Aluno)/3;
    }

}
