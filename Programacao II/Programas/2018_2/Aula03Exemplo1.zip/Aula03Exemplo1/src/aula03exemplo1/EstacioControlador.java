package aula03exemplo1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author alunoti
 */
public class EstacioControlador {
     private AlunoView alunoView;
    public void executar(){
        alunoView = new AlunoView();
        InteligenciaBotao ib = new InteligenciaBotao();
        alunoView.adicionaListenerBotao(ib);
        
    }
    private class InteligenciaBotao implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            AlunoModelo am = alunoView.obtemAlunoModelo();
            double m = am.calculaMedia();
                        
            alunoView.atualizaMedia(m);
        }
    
    
}
    
    
}
