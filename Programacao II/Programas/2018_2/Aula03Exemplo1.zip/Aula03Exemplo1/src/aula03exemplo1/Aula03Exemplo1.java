package aula03exemplo1;

/**
 *
 * @author alunoti
 */
public class Aula03Exemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        EstacioControlador ec = new EstacioControlador();
        ec.executar();
    }
    
}
