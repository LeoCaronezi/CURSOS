package aula03exemplo1;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author alunoti
 */
public class AlunoView {

    //1.1 - Declarar atributos do JFrame(janela)
    private JFrame alunoJFrame; //JANELA

    private JLabel alunoJLabel; //Label Aluno
    private JTextField alunoJTextField; //Campo Aluno

    private JLabel av1JLabel; //Label Av1
    private JTextField av1JTextField;// Campo Av1

    private JLabel av2JLabel; //Label Av2
    private JTextField av2JTextField; //Campo Av2

    private JLabel av3JLabel; //Label Av3;
    private JTextField av3JTextField; // Campo Av3

    private JLabel mediaJLabel; // Label Media
    private JTextField mediaJTextField;// Campo Media

    private JButton calculaJButton;

    //1.2 - 
    public AlunoView() {
        alunoJFrame = new JFrame("Calcular Média"); //Instanciando a Janela(JFrame)    
        alunoJFrame.setSize(500, 500);//Define o tamanho da Janela         
        alunoJFrame.setLayout(new FlowLayout());//
        alunoJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Para o programa ao fechar a janela

        alunoJLabel = new JLabel("Aluno");// Instancia o Label Aluno
        alunoJTextField = new JTextField(30); // Instancia o Campo do Aluno

        av1JLabel = new JLabel("Av1");// Instancia o Label da Av1
        av1JTextField = new JTextField(5);// Instancia o Campo da Av1

        av2JLabel = new JLabel("Av2");// Instancia o Label da Av2
        av2JTextField = new JTextField(5);// Instancia o Campo da Av2

        av3JLabel = new JLabel("Av3");// Instancia o Label da Av3
        av3JTextField = new JTextField(5); // Instancia o Campo da Av3

        mediaJLabel = new JLabel("Media");// Instancia o Label da Media
        mediaJTextField = new JTextField(5);// Instancia o Campo da Media

        calculaJButton = new JButton("Calcular");

        alunoJFrame.add(alunoJLabel);//Adiciona o Label do aluno na Janela
        alunoJFrame.add(alunoJTextField);//Adiciona o campo do aluno na Janela
        alunoJFrame.add(av1JLabel);//Adiciona o Label da av1 na Janela
        alunoJFrame.add(av1JTextField);//Adiciona o campo da Av1 na Janela
        alunoJFrame.add(av2JLabel);//Adiciona o Label do av2 na Janela
        alunoJFrame.add(av2JTextField);//Adiciona o campo da Av2 na Janela
        alunoJFrame.add(av3JLabel);//Adiciona o Label da Av3 na Janela
        alunoJFrame.add(av3JTextField);//Adiciona o campo da Av3 na Janela
        alunoJFrame.add(mediaJLabel);//Adiciona o Label da Media na Janela
        alunoJFrame.add(mediaJTextField);//Adiciona o campo da Media na Janela
        alunoJFrame.add(calculaJButton);

        alunoJFrame.setVisible(true);//Torna a Janela(JFrame) visivel
    }
    //Fala com o Model - Passando os valores dos campos
    public AlunoModelo obtemAlunoModelo() {
        double av1 = Double.parseDouble(av1JTextField.getText());
        double av2 = Double.parseDouble(av2JTextField.getText());
        double av3 = Double.parseDouble(av3JTextField.getText());             
        AlunoModelo a = new AlunoModelo(alunoJTextField.getText(), av1, av2, av3);
        return a;
    }
    
    //Recebe do Controlador o calculo da media e seta no campo media
    public void atualizaMedia(double media){
        mediaJTextField.setText("" + media);
    }

    //Fala com o controlador
    public void adicionaListenerBotao(ActionListener l) {
        calculaJButton.addActionListener(l);
    }

}
