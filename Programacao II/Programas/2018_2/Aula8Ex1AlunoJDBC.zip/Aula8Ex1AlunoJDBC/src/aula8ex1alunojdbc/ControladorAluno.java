
package aula8ex1alunojdbc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

public class ControladorAluno {
    private AlunoJFrame viewAluno;
    private ControladorBANCO bancoAluno;
        
    public void executar(){
        // Criar objetos view 
        viewAluno = new AlunoJFrame();
        // Colocar listeners
        viewAluno.addInsereListener(new InsereListener());
        viewAluno.addLeBancoListener(new LeBancoListener());
        viewAluno.addInsereBancoListener(new InsereBancoListener());
        // Disparar Views
        viewAluno.setVisible(true);
        // Inicializar Banco de Dados
        bancoAluno = new ControladorBANCO();
    };
    // Criar uma classe Listener para o botao INSERE
    public class InsereListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
           /// Codigo para inserir 
           // 1 - Obter objeto digitado nos campos de entrada
           Aluno a = viewAluno.obterAlunoDigitado();
           // 2 - Chamar metodo de inserir na lista
           viewAluno.insereAlunoLista(a);
           // 3 - Chamar metodo para inserir no banco de dados           
           /// AGUARDEM /// 
        }        
    }
    // Criar uma classe Lister para o botao LA BANCO
    public class LeBancoListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            /// 1 - Limpar a lista da view
            viewAluno.limpaLista();
            /// 2 - Ler o Banco de dados  /  3 - obter a lista da dados do banco
            ArrayList<Aluno> lista = bancoAluno.lerBanco();
            Iterator<Aluno> it = lista.iterator();
            while(it.hasNext()){
                Aluno a = it.next();
                viewAluno.insereAlunoLista(a);
            } 
        }        
    }
    //Criar Classe Listener para o BOTAO Insere Banco
    public class InsereBancoListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
         //Inserir no banco de dados                    
           // 1 - Obter objeto digitado nos campos de entrada
           Aluno a = viewAluno.obterAlunoDigitado();
           // 2 - Chamar metodo de inserir na lista
           //viewAluno.insereAlunoLista(a);
           // 3 - Chamar metodo para inserir no banco de dados           
           bancoAluno.inserirBanco(a);         
        }        
    }
}
