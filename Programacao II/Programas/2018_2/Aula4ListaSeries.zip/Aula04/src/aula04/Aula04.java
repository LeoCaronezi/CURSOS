package aula04;
public class Aula04 {

    
    public static void main(String[] args) {
       ControladorPersonagem A = new ControladorPersonagem();
       A.executar();
    }
    
}
