package aula04;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.text.html.HTMLDocument;

public class ControladorPersonagem {
    private Jujubinha personagemView;
    private Lista persagemModelo;
    
    
    public void executar(){
        personagemView = new Jujubinha();
        personagemView.setVisible(true);
        persagemModelo = new Lista(" ");
        InsereListener J = new InsereListener();
        personagemView.adcionarLista(J);
        ConsoleListener k = new ConsoleListener();
        personagemView.acrescentarLista(k);
   
    }
    
    public class InsereListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
           Personagem x = personagemView.retornaPersonagem();
           String serie = personagemView.retornaSerie();
           persagemModelo.insere(x);
           persagemModelo.setSerie(serie);
        }
    
    }
    
    
    public class ConsoleListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            ArrayList<Personagem> a = persagemModelo.getArrayLista();
            Iterator<Personagem> it = a.iterator();
            while (it.hasNext()) {
                Personagem p = it.next();
                System.out.println("Personagem: " + p.getNomePersonagem());
            }
        }
    
    }
    
    
}
