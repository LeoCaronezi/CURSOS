package aula04;

import java.util.ArrayList;

public class Lista {
    private String serie;
    private ArrayList<Personagem> arrayLista;

    public Lista(String serie) {
        this.serie = serie;
        
        arrayLista = new ArrayList<Personagem>();
    }
    
    public void insere(Personagem P){
        arrayLista.add(P);
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public ArrayList<Personagem> getArrayLista() {
        return arrayLista;
    }
    
    
}
