package aula04;
public class Personagem {
    private String nomePersonagem;
    private int idadePersonagem;
    private String atorPersonagem;
    boolean principalPersonagem;

    public Personagem(String nomePersonagem, int idadePersonagem, String atorPersonagem, boolean principalPersonagem) {
        this.nomePersonagem = nomePersonagem;
        this.idadePersonagem = idadePersonagem;
        this.atorPersonagem = atorPersonagem;
        this.principalPersonagem = principalPersonagem;
    }

    public String getNomePersonagem() {
        return nomePersonagem;
    }

    public int getIdadePersonagem() {
        return idadePersonagem;
    }

    public String getAtorPersonagem() {
        return atorPersonagem;
    }

    public boolean isPrincipalPersonagem() {
        return principalPersonagem;
    }
    
    
    
 
    
}
