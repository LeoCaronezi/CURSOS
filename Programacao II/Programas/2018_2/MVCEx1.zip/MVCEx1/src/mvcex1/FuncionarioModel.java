/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvcex1;

/**
 *
 * @author aluno
 */
public class FuncionarioModel {
    private String nomeFuncionario;
    private double salarioFuncionario;
    
    public FuncionarioModel(String nomeFuncionario, double salarioFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
        this.salarioFuncionario = salarioFuncionario;
    }

    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public double getSalarioFuncionario() {
        return salarioFuncionario;
    }

    public void aumentaSalario(double taxa){
        salarioFuncionario = salarioFuncionario * taxa;
    }


    
}
