/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvcex1;

/**
 *
 * @author aluno
 */
public class EmpresaControlador {   
   private FuncionarioView funcionarioView;
   private FuncionarioModel funcionarioModel;
   
   public FuncionarioModel processaFuncionario(FuncionarioModel fm){
       fm.aumentaSalario(1.5);
       return fm;
   }
   
    public void Executar(){
        System.out.println("Iniciando Controlador");
        funcionarioView = new FuncionarioView();
        
        funcionarioModel = funcionarioView.lerFuncionario();
        //////
        processaFuncionario(funcionarioModel);
        //////
        funcionarioView.mostraFuncionario(funcionarioModel);
        
    }
}
