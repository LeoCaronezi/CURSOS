/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvcex1;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class FuncionarioView {
    
    public FuncionarioModel lerFuncionario(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Insira o nome:");
        String nome = sc.next();
        System.out.println("Insira o salario:");
        double salario = sc.nextDouble();        
        
        FuncionarioModel fm = new FuncionarioModel(nome, salario);
        return fm;     
    }
    
    public void mostraFuncionario(FuncionarioModel fm){
        System.out.println("-----------------------");
        
        System.out.println("Funcionario: "+fm.getNomeFuncionario());
        System.out.println("Salario: "+fm.getSalarioFuncionario());
        
        System.out.println("-----------------------");        
    }
    
    
}
