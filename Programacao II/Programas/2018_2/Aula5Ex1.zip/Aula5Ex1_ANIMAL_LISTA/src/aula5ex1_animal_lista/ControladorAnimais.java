/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5ex1_animal_lista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author alunoti
 */
public class ControladorAnimais {
    /// Declaramos a referencia para o Modelo e a View
    private ListaAnimais animalModel;
    private AnimalViewJFrame animalViewJFrame;
    
    // Iniciamos a execucao do Projeto
    public void executar(){
        // Criamos o objeto do Modelo
        animalModel = new ListaAnimais();
        //Criamos o objeto da View
        animalViewJFrame = new AnimalViewJFrame();
        // Criamos o Listener
        InsereAnimalListener iAl = new InsereAnimalListener();
         
        //Coloca Listener na View
        animalViewJFrame.addInsereListener(iAl);
        
        
        //Disparamos a View
        animalViewJFrame.setVisible(true);
    }
    /// Criamos a classe que vai ser o Manipulador do botao INSERE
    public class InsereAnimalListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            // Pegar o objeto digitado na view
            Animal a = animalViewJFrame.obtemAnimalDigitado();
            
            // insere no Modelo
            animalModel.insereAnimal(a);
            
            //////////////////////
            animalViewJFrame.insereAnimalLista(a);
            
            animalViewJFrame.insereSegundoAnimal(new Animal("Jujuba", 85000));
            
            
        }        
    }
    //-----------------------------------------------------
    
    
    
    
    
    
}
