package aula5ex1_animal_lista;


public class Aula5Ex1_ANIMAL_LISTA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ControladorAnimais ca = new ControladorAnimais();
        ca.executar();
    }
    
}
