/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5ex1_animal_lista;

import java.util.ArrayList;
import java.util.Iterator;


/**
 *
 * @author alunoti
 */
public class ListaAnimais {
    private ArrayList<Animal> listaAnimais;

    public ListaAnimais() {
        listaAnimais = new ArrayList<Animal>();      
    }    
   
    public void insereAnimal(Animal animal){
        listaAnimais.add(animal);
    }
    





//////////////////////////////////////////
    public Animal buscaAnimalNome(String nome){
        Iterator<Animal> it = listaAnimais.iterator();
        Animal retornado = new Animal("Nao Achado", 0);
        while(it.hasNext()){
            Animal a = (Animal) it.next();
            if(nome.equalsIgnoreCase(a.getNomeAnimal())){
                retornado = a;
            }
        }
        return retornado;        
    }
    
    
    
}
