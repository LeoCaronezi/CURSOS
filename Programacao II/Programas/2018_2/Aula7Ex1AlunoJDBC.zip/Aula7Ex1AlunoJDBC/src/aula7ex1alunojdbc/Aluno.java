package aula7ex1alunojdbc;
public class Aluno {
        String nomeAluno;
        int    notaAluno;
    public Aluno(String nome, int nota) {
        this.nomeAluno = nome;
        this.notaAluno = nota;
    }
    public String getNomeAluno() {
        return nomeAluno;
    }
    public int getNotaAluno() {
        return notaAluno;
    }
    @Override
    public String toString() {
        return nomeAluno + " - NOTA: " + notaAluno;
    }    
}
