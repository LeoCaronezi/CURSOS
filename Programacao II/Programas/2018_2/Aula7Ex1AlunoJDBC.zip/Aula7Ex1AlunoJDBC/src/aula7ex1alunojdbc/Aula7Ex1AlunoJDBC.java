/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula7ex1alunojdbc;


public class Aula7Ex1AlunoJDBC {

    public static void main(String[] args) {
        ControladorAluno ca = new ControladorAluno();
        ca.executar();        
    }
    
}
