/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula7ex1alunojdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ControladorBANCO {
    // link de conexao com o banco
    private String URL_DB = "jdbc:derby://localhost:1527/ALUNODB/";
    // Comando SQL para ler o banco
    private String CONSULTA_ALUNO = "SELECT NOME,NOTA "
                                  + "FROM ALUNO";
    /// Objeto de Conexao com o banco
    private Connection conexaoDB;
    // Construtor que faz a conexao com o banco 
    public ControladorBANCO() {
        try{
            conexaoDB = DriverManager.getConnection(URL_DB, "userdb", "userdb");            
        }catch(Exception e){
            System.out.println("Erro "+e);
        }
    }
    // Ler regisros do Banco e retornar em objetos da lista
    public ArrayList<Aluno> lerBanco(){
        // Lista que vai retornar
        ArrayList<Aluno> lista = new ArrayList<Aluno>();
        try{
            // Objeto JAVA para executar o SQL
            Statement comando = conexaoDB.createStatement();
            // Executa o SQL
            ResultSet resultado = comando.executeQuery(CONSULTA_ALUNO);

            // Percorre todos os resultados
            while(resultado.next()){
                // Cria um objeto aluno para cada registro retornado
                String nome = resultado.getString("NOME");
                int    nota = resultado.getInt("NOTA");
                Aluno a = new Aluno(nome, nota);
                lista.add(a);
            }        
        }catch(Exception e){
            System.out.println("Erro "+e);
        }
        return (lista);
    }
    
    
    
}
