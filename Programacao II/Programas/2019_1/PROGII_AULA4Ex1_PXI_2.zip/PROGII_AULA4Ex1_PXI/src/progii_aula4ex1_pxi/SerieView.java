/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progii_aula4ex1_pxi;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class SerieView {
    private JFrame      serieJFrame;

    private JLabel      nomeSerieJLabel;
    private JTextField  nomeSerieJTextField;

    private JLabel      nrEpisodiosJLabel;
    private JTextField  nrEpisodiosJTextField;

    private JLabel      precoEpisodioJLabel;
    private JTextField  precoEpisodioJTextField;

    private JLabel      totalPrecoJLabel;
    private JTextField  totalPrecoJTextField;
    
    private JButton     insereButton;
    /////////////////////////////////////////////////
    public SerieView(){

        serieJFrame = new JFrame("NertFrix");
        serieJFrame.setSize(300,400);
        serieJFrame.setLayout(new FlowLayout());
        serieJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        nomeSerieJLabel     = new JLabel("Nome da Serie:");
        nomeSerieJTextField = new JTextField(20);

        nrEpisodiosJLabel       = new JLabel("Nr. Episodios:");
        nrEpisodiosJTextField   = new JTextField(2);
        precoEpisodioJLabel     = new JLabel("Preco Aluguel R$ ");
        precoEpisodioJTextField = new JTextField(5);

        totalPrecoJLabel        = new JLabel("Total Preco R$ ");
        totalPrecoJTextField    = new JTextField(5);
       
        insereButton            = new JButton("Inserir");
        
        //////////////////////////////////////////  
        serieJFrame.add(nomeSerieJLabel);
        serieJFrame.add(nomeSerieJTextField);
        serieJFrame.add(nrEpisodiosJLabel);
        serieJFrame.add(nrEpisodiosJTextField);
        serieJFrame.add(precoEpisodioJLabel);
        serieJFrame.add(precoEpisodioJTextField);
        serieJFrame.add(totalPrecoJLabel);
        serieJFrame.add(totalPrecoJTextField);
        
        serieJFrame.add(insereButton);
        ////////////////////////
        serieJFrame.setVisible(true);        
    }
    
    public void mostrarSerie(Serie s){
        nomeSerieJTextField.setText(s.getNomeSerie());
        nrEpisodiosJTextField.setText(""+s.getNrEpisodios());
        precoEpisodioJTextField.setText(""+s.getAluguelEpisodio());
        totalPrecoJTextField.setText(""+s.totalAluguel());
   }
   
   public Serie retornaSerieDigitada(){
       String nome  = nomeSerieJTextField.getText();
       int    nrEp  = Integer.parseInt(nrEpisodiosJTextField.getText());
       double preco = Double.parseDouble(precoEpisodioJTextField.getText());
       Serie s = new Serie(nome, nrEp, preco);
       return s;
   }
   
   public void colocarInserirListener(ActionListener al){
       insereButton.addActionListener(al);       
   }
    
}
