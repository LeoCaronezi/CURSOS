/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progii_aula4ex1_pxi;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NetFlixControlador {
        private SerieView sv;
        private Serie s1;
        
    public void executar(){
        //1 = new Serie("GOT", 6, 10);
        
        sv = new SerieView();
        
        sv.colocarInserirListener(new inserirSerie());
        //sv.mostrarSerie(s1);        
    }
    
    public class inserirSerie implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            s1 = sv.retornaSerieDigitada();
            sv.mostrarSerie(s1);
        }
        
    }
    
    
}
