package aula6ex1curso;


public class Aula6Ex1CURSO {

    public static void main(String[] args) {
        CursosControlador cc = new CursosControlador();
        cc.executar();
    }
    
}
