package aula6ex1curso;

public class Curso {
    private String nomeCurso;
    private double precoCurso;

    public Curso(String nomeCurso, double precoCurso) {
        this.nomeCurso = nomeCurso;
        this.precoCurso = precoCurso;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public double getPrecoCurso() {
        return precoCurso;
    }
    
    
}
