
package aula5ex1processos;

public class Aula5Ex1Processos {

    public static void main(String[] args) {
        CartorioControlador cc = new CartorioControlador();
        cc.iniciarPrograma();
        
    }
    
}
