
package aula6ex1listasviagem;

public class Viagem {
    private String destinoViagem;
    private int    milhasViagem;

    public Viagem(String destinoViagem, int milhasViagem) {
        this.destinoViagem = destinoViagem;
        this.milhasViagem = milhasViagem;
    }

    public String getDestinoViagem() {
        return destinoViagem;
    }

    public int getMilhasViagem() {
        return milhasViagem;
    }

    @Override
    public String toString() {
        return "Destino:" + destinoViagem ;
    }

  
    
}
