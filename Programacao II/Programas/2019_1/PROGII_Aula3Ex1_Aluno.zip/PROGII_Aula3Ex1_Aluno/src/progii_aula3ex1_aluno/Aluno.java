
package progii_aula3ex1_aluno;

public class Aluno {
    private String nomeAluno;
    private int    periodoAluno;
    private double av1Nota,av2Nota,av3Nota;

    public Aluno(String nomeAluno, int periodoAluno, 
                 double av1Nota, double av2Nota, double av3Nota) {
        this.nomeAluno = nomeAluno;
        this.periodoAluno = periodoAluno;
        this.av1Nota = av1Nota;
        this.av2Nota = av2Nota;
        this.av3Nota = av3Nota;
    }
    public double calculaMedia(){
        if(av1Nota >= av2Nota){
            if(av3Nota <= av2Nota){
                return((av1Nota+av2Nota)/2);
            }else{
                return((av1Nota+av3Nota)/2);
            }            
        }else{
            if(av3Nota <= av1Nota){
                return((av1Nota+av2Nota)/2);
            }else{
                return((av2Nota+av3Nota)/2);
            }
        }        
    }
    

    public String getNomeAluno() {
        return nomeAluno;
    }

    public int getPeriodoAluno() {
        return periodoAluno;
    }

    public double getAv1Nota() {
        return av1Nota;
    }

    public double getAv2Nota() {
        return av2Nota;
    }

    public double getAv3Nota() {
        return av3Nota;
    }
    
    
    
    
}
