
package progii_aula3ex1_aluno;

public class PROGII_Aula3Ex1_Aluno {

   
    public static void main(String[] args) {
        //Criar o controlador e mandar executar
        ControladorAluno ca = new ControladorAluno();
        ca.executar();
    }
    
}
