
package progii_aula3ex1_aluno;

import javax.swing.JOptionPane;

public class AlunoView {
    
    public Aluno leAluno(){
        String nome    = JOptionPane.showInputDialog("Aluno ?");
        int    periodo = Integer.parseInt(JOptionPane.showInputDialog("Periodo ?"));
        double av1     = Double.parseDouble(JOptionPane.showInputDialog("Nota Av1 ?"));
        double av2     = Double.parseDouble(JOptionPane.showInputDialog("Nota Av2 ?"));
        double av3     = Double.parseDouble(JOptionPane.showInputDialog("Nota Av3 ?"));
        
        Aluno a = new Aluno(nome, periodo, av1, av2, av3);
        
        return a;
    }
    public void mostraAluno(Aluno a){
        JOptionPane.showMessageDialog(null, "Aluno: " +a.getNomeAluno()+
                                            "\nPeriodo:"+a.getPeriodoAluno()+
                                            "\n A1:"+a.getAv1Nota()+
                                            " - A2:"+a.getAv2Nota()+
                                            " - A3:"+a.getAv3Nota()+                
                                            "\nMedia :"+a.calculaMedia());
    }
    
}
