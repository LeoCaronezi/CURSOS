
package progii_aula3ex1_aluno;

public class ControladorAluno {
    public void executar(){
        AlunoView av = new AlunoView();
        
        Aluno am = av.leAluno();        
        av.mostraAluno(am);
    }
}
