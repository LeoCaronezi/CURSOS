/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula7ex1jdbc_exames;

/**
 *
 * @author andre
 */
public class Aula7Ex1JDBC_EXAMES {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            ControladorMedico cm = new ControladorMedico();
            cm.executar();
    }
    
}
