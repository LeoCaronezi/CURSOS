package aula6ex1pais;

public class Pais {
    private String nomePais;
    private int    popPais;

    public Pais(String nomePais, int popPais) {
        this.nomePais = nomePais;
        this.popPais = popPais;
    }
    public String getNomePais() {
        return nomePais;
    }
    public int getPopPais() {
        return popPais;
    }   
}
