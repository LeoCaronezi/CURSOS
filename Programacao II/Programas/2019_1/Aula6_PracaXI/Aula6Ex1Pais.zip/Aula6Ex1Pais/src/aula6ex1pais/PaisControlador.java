package aula6ex1pais;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class PaisControlador {
       private PaisView paisView;
       private ArrayList<Pais> listaPaises;      
       // Classe interna para o manipulador de Eventos
       private class InserirListener implements 
                                     ActionListener{
            @Override
            public void actionPerformed(ActionEvent e) {
                // O que vai ser feito quando o botao da view for clicado
                Pais p = paisView.obterPais();
                listaPaises.add(p);
                paisView.colocarStatus(p.getNomePais() + "-Inserido");          
            }           
       }
       //------------------------------------------
       public void executar(){
           paisView = new PaisView();
           listaPaises = new ArrayList<Pais>();
           paisView.addInserirListener(new InserirListener());
       }    
}
