package aula6ex1pais;

public class Aula6Ex1Pais {

    public static void main(String[] args) {
        PaisControlador pc = new PaisControlador();
        pc.executar();
    }
    
}
