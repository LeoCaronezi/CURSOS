package aula6ex1pais;

import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class PaisView {
    private JFrame      paisJFrame;
    private JLabel      nomePaisJLabel;
    private JTextField  nomePaisJTextField;
    private JLabel      popPaisJLabel;
    private JTextField  popPaisJTextField;
    private JButton     inserirJButton;
    private JLabel      statusJLabel;
    
    public PaisView(){
        paisJFrame = new JFrame("Painel Entrada de Pais");
        paisJFrame.setSize(300, 300);
        paisJFrame.setLayout(new FlowLayout());
        paisJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //------------------//
        nomePaisJLabel     = new JLabel("Pais:");
        nomePaisJTextField = new JTextField(10);
        popPaisJLabel     = new JLabel("Pop:");
        popPaisJTextField = new JTextField(3);
        
        inserirJButton = new JButton("Inserir Pais");        
        statusJLabel   = new JLabel("STATUS");
        //-----------------------------------
        paisJFrame.add(nomePaisJLabel);
        paisJFrame.add(nomePaisJTextField);
        paisJFrame.add(popPaisJLabel);
        paisJFrame.add(popPaisJTextField);
        paisJFrame.add(inserirJButton);
        paisJFrame.add(statusJLabel);        
        paisJFrame.setVisible(true);
    }
    public Pais obterPais(){
        String nome = nomePaisJTextField.getText();
        int    pop  = Integer.parseInt(popPaisJTextField.getText());        
        Pais p = new Pais(nome, pop);       
        return p;
    }
    public void colocarStatus(String s){
        statusJLabel.setText(s);        
    }
    public void addInserirListener(ActionListener al){
        inserirJButton.addActionListener(al);
    }
}
