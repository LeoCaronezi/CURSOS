/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progii_aula4ex1_pxi;

public class NetFlixControlador {
    public void executar(){
        Serie s1 = new Serie("GOT", 6, 10);
        
        SerieView sv = new SerieView();
        sv.mostrarSerie(s1);
        
    }
    
}
