/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progii_aula4ex1_pxi;

/**
 *
 * @author professor
 */
public class Serie {
    private String nomeSerie;
    private int    nrEpisodios;
    private double aluguelEpisodio;

    public Serie(String nomeSerie, int nrEpisodios, double aluguelEpisodio) {
        this.nomeSerie = nomeSerie;
        this.nrEpisodios = nrEpisodios;
        this.aluguelEpisodio = aluguelEpisodio;
    }

    public double totalAluguel(){
        return nrEpisodios * aluguelEpisodio;
    }
    
    public String getNomeSerie() {
        return nomeSerie;
    }

    public int getNrEpisodios() {
        return nrEpisodios;
    }

    public double getAluguelEpisodio() {
        return aluguelEpisodio;
    }
    
    
    
    
    
}
