/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula9ex1crud_maquina;

/**
 *
 * @author aluno
 */
public class Maquina {
    private String nomeMaquina;
    private double precoMaquina;

    public Maquina(String nomeMaquina, double precoMaquina) {
        this.nomeMaquina = nomeMaquina;
        this.precoMaquina = precoMaquina;
    }

    public String getNomeMaquina() {
        return nomeMaquina;
    }

    public double getPrecoMaquina() {
        return precoMaquina;
    }

    @Override
    public String toString() {
        return "=>" + nomeMaquina + "<=";
    }
    
    
    
}
