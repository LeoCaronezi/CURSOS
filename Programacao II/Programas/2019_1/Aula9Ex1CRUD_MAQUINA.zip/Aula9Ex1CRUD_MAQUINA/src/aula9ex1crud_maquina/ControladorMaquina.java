/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula9ex1crud_maquina;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author aluno
 */
public class ControladorMaquina {
    private ArrayList<Maquina> listaMaquinas;
    private MaquinaViewJFrame maquinasView;
    private BancoMaquina      bancoMaquina;

    private class LimparListaListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            listaMaquinas.clear();
            maquinasView.limparLista();
        }        
    }
    private class InserirListaListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            Maquina m = maquinasView.obterMaquinaDigitada();
            listaMaquinas.add(m);
            maquinasView.inserirMaquinaLista(m);
        }        
    }
    private class InserirBancoListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            Maquina m = maquinasView.obterMaquinaDigitada();
            bancoMaquina.inserirBanco(m);
        }        
    }
    private class CarregaListaListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            listaMaquinas.clear();
            bancoMaquina.carregarBanco(listaMaquinas);
            maquinasView.limparLista();
            Iterator<Maquina> it = listaMaquinas.iterator();
            while(it.hasNext()){
                Maquina m = (Maquina)it.next();
                maquinasView.inserirMaquinaLista(m);
            }            
        }        
    }
    private class LimparBancoListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            listaMaquinas.clear();
            maquinasView.limparLista();
            bancoMaquina.limparBanco();
        }        
    }
    private class RemoveMaquinaListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            Maquina m = maquinasView.obterMaquinaDigitada();
            bancoMaquina.removerBanco(m);                        
        }        
    }   
    private class AlteraMaquinaListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            Maquina m = maquinasView.obterMaquinaDigitada();
            bancoMaquina.alterarBanco(m);            
        }        
    }
    private class SelecionaItemListener implements ListSelectionListener{
        @Override
        public void valueChanged(ListSelectionEvent e) {
            Maquina m = maquinasView.obterMaquinaSelecionada();
            maquinasView.inserirPrecoMaquinaSelecionada(m.getPrecoMaquina());
        }
    }
    
    public void executar(){
        listaMaquinas = new ArrayList<Maquina>();
        bancoMaquina  = new BancoMaquina();
        
        maquinasView  = new MaquinaViewJFrame();
        maquinasView.addAlteraMaquinaListener(new AlteraMaquinaListener());
        maquinasView.addSelecionaItemListener(new SelecionaItemListener());
        maquinasView.addRemoveMaquinaListener(new RemoveMaquinaListener());
        maquinasView.addCarregarListaListener(new CarregaListaListener());
        maquinasView.addLimparBancoListener(new LimparBancoListener());
        maquinasView.addLimparListaListener(new LimparListaListener());
        maquinasView.addInserirBancoListener(new InserirBancoListener());
        maquinasView.addInserirListaListener(new InserirListaListener());
        
        maquinasView.setVisible(true);
    }    
}
