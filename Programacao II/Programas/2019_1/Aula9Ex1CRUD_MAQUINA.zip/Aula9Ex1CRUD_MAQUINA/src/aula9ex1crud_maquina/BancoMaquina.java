/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula9ex1crud_maquina;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author aluno
 */
public class BancoMaquina {
    private String DB_URL = "jdbc:derby://localhost:1527/MAQUINADB/";
    private Connection conexaoDB;

    public BancoMaquina() {
        try{
            conexaoDB = DriverManager.getConnection(DB_URL,
                                                    "userdb",
                                                    "userdb");            
        }catch(SQLException e){
            System.out.println("Erro de conexao:"+e);
        }            
    }
    public void inserirBanco(Maquina m){
        try{
            Statement comando = conexaoDB.createStatement();
            String sqlinsere = "INSERT INTO MAQUINA_TB"
                    + "(NOME,PRECO) "
                    + "VALUES("
                    + "\'" + m.getNomeMaquina() + "\',"
                    + m.getPrecoMaquina()
                    + ")";
            comando.executeUpdate(sqlinsere);
            comando.close();
        }catch(SQLException e){
            System.out.println("Erro de insercao:"+e);
        }
        
    }
    public void carregarBanco(ArrayList<Maquina> lista){
        try{
            Statement comando = conexaoDB.createStatement();
            String sqlQuery = "SELECT NOME,PRECO "
                            + "FROM MAQUINA_TB";
            ResultSet resultado = comando.executeQuery(sqlQuery);
            while(resultado.next()){
                String nome  = resultado.getString("NOME");
                double preco = resultado.getDouble("PRECO");
                Maquina m = new Maquina(nome, preco);
                lista.add(m);
            }
            comando.close();
        }catch(SQLException e){
            System.out.println("Erro de carga:"+e);
        }        
    }
    public void limparBanco(){
        try{
            Statement comando = conexaoDB.createStatement();
            String sqldelall = "DELETE "
                             + "FROM MAQUINA_TB ";
            comando.executeUpdate(sqldelall);
            comando.close();           
        }catch(SQLException e){
            System.out.println("Erro de limpeza do banco:"+e);
        }
    }
    public void removerBanco(Maquina m){
        try{
            Statement comando = conexaoDB.createStatement();
            String sqldel = "DELETE "
                          + "FROM MAQUINA_TB "
                          + "WHERE NOME = "
                          + "\'" + m.getNomeMaquina() + "\'";
            comando.executeUpdate(sqldel);
            comando.close();            
        }catch(SQLException e){
            System.out.println("Erro de Remocao:"+e);
        }
    }
    public void alterarBanco(Maquina m){
        try{
            Statement comando = conexaoDB.createStatement();
            String sqlupdate = "UPDATE MAQUINA_TB "
                             + "SET PRECO = "
                             + m.getPrecoMaquina()                           
                             +" WHERE NOME = "
                             + "\'" + m.getNomeMaquina() + "\'";
            comando.executeUpdate(sqlupdate);
            comando.close();
        }catch(SQLException e){
            System.out.println("Erro de alteracao:"+e);
        }
    }
    
}
