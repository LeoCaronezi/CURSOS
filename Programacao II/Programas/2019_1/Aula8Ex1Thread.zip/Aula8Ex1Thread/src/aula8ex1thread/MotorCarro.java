/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula8ex1thread;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author professor
 */
public class MotorCarro implements Runnable{
    private CarrosJPanel painel;
    
    public MotorCarro(CarrosJPanel cjp){
        painel = cjp;
    }
    @Override
    public void run() {
        while(painel.isIniciar()){
            painel.moverAleatorio();
            painel.repaint();
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                Logger.getLogger(MotorCarro.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
  
}
