package progiiaula3ex1livros;

public class PROGIIAula3Ex1Livros {

    public static void main(String[] args) {
        LivrariaControlador lc = new LivrariaControlador();
        lc.executarLivraria();
    }

}
