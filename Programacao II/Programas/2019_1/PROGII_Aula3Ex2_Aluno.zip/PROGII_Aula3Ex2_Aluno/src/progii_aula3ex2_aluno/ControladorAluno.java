
package progii_aula3ex2_aluno;

public class ControladorAluno {
    public void executar(){
        AlunoView av = new AlunoView();
        
        Aluno am = new Aluno("Bart Simpson",4, 5.0, 6.5, 7.5);
        av.mostraAluno(am);
    }
}
