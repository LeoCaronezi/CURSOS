
package progii_aula3ex2_aluno;

import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
    



public class AlunoView {
    private JFrame alunoFrame;    
    private JLabel      alunoJLabel;
    private JTextField  alunoJTextField;
    
    private JLabel      periodoJLabel;
    private JTextField  perioJTextField;
    
    private JLabel      av1NotaJLabel;
    private JTextField  av1NotaJTextField;
    
    private JLabel      av2NotaJLabel;
    private JTextField  av2NotaJTextField;
    
    private JLabel      av3NotaJLabel;
    private JTextField  av3NotaJTextField;

    private JLabel      totalNotaJLabel;
    private JTextField  totalNotaJTextField;
    
    public AlunoView(){
        
        alunoFrame = new JFrame("Dados de Aluno");
        alunoFrame.setSize(300, 300);
        alunoFrame.setLayout(new FlowLayout());
        alunoFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        alunoJLabel        = new JLabel("Aluno");
        alunoJTextField    = new JTextField(10);
        periodoJLabel      = new JLabel("Periodo:");
        perioJTextField    = new JTextField(2);
        av1NotaJLabel      = new JLabel("Av1:");
        av1NotaJTextField  = new JTextField(3);
        av2NotaJLabel      = new JLabel("Av2:");
        av2NotaJTextField  = new JTextField(3);
        av3NotaJLabel      = new JLabel("Av3:");
        av3NotaJTextField  = new JTextField(3);
        totalNotaJLabel      = new JLabel("Media:");
        totalNotaJTextField  = new JTextField(3);

        alunoFrame.add(alunoJLabel);
        alunoFrame.add(alunoJTextField);
        alunoFrame.add(periodoJLabel);
        alunoFrame.add(perioJTextField);
        alunoFrame.add(av1NotaJLabel);
        alunoFrame.add(av1NotaJTextField);
        alunoFrame.add(av2NotaJLabel);
        alunoFrame.add(av2NotaJTextField);
        alunoFrame.add(av3NotaJLabel);
        alunoFrame.add(av3NotaJTextField);
        alunoFrame.add(totalNotaJLabel);
        alunoFrame.add(totalNotaJTextField);
        alunoFrame.setVisible(true);        
    }
    
     public void mostraAluno(Aluno a){
        alunoJTextField.setText(a.getNomeAluno());
        perioJTextField.setText(""+a.getPeriodoAluno());
        av1NotaJTextField.setText(""+a.getAv1Nota());
        av2NotaJTextField.setText(""+a.getAv2Nota());
        av3NotaJTextField.setText(""+a.getAv3Nota());
        totalNotaJTextField.setText(""+a.calculaMedia());
        
    }
    
}
