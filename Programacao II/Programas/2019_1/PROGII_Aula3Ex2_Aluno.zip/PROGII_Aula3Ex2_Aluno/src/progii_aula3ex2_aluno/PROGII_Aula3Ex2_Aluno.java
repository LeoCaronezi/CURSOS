
package progii_aula3ex2_aluno;

public class PROGII_Aula3Ex2_Aluno {

   
    public static void main(String[] args) {
        //Criar o controlador e mandar executar
        ControladorAluno ca = new ControladorAluno();
        ca.executar();
    }
    
}
