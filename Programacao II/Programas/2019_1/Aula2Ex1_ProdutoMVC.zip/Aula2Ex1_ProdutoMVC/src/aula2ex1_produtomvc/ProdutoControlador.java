/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula2ex1_produtomvc;

/**
 *
 * @author aluno
 */
public class ProdutoControlador {
    
    public void executar(){
        //Aqui vai ficar o codigo do controlador DEPOIS
        // 1 - Criar a View
        ProdutoView pv = new ProdutoView();
        // 2 - Criar o Modelo
        ProdutoModelo pm;
        //3 - Obter o Modelo da view
        pm = pv.leProduto();
        //4 - Mostrar o Modelo na view
        pv.mostraProduto(pm);
        
        
        
        
    }
    
}
