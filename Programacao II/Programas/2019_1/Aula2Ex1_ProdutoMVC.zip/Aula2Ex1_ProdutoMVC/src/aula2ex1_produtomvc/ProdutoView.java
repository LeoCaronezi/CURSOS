
package aula2ex1_produtomvc;

import javax.swing.JOptionPane;

public class ProdutoView {
    
    public ProdutoModelo leProduto(){
        String nome  = JOptionPane.showInputDialog(null, "Produto ?");
        double preco = Double.parseDouble(JOptionPane.showInputDialog(null, "Preco ?"));
        int    qde   = Integer.parseInt(JOptionPane.showInputDialog(null, "Quantidade ?"));
        ProdutoModelo pm = new ProdutoModelo(nome, preco, qde);
        return pm;
    }
    public void mostraProduto(ProdutoModelo pm){
        JOptionPane.showMessageDialog(null, "Produto"+pm.getNomeProduto() +
                                            "Total R$ "+pm.calculaTotal());        
    }
    
}
