/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula7ex1_servico_lista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

public class ServicoControlador {
        private ServicoViewJFrame   servicoViewJFrame;
        private ArrayList<Servico>  listaServicos;
    
        protected class InserirServicoListener implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent e) {
                Servico s = servicoViewJFrame.obterServicoDigitado();
                listaServicos.add(s);
                /// Esse e para o JList
                servicoViewJFrame.inserirLista(s);
                //////////////////////
            }            
        }
        protected class LimparServicosListener implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent e) {
                listaServicos.clear();
                servicoViewJFrame.limparLista();                
            }            
        }
        protected class TotalServicosListener implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent e) {
                Iterator<Servico> it = listaServicos.iterator();
                double total = 0;
                while(it.hasNext()){
                    Servico s = it.next();
                    total += s.getPrecoServico();
                }
                servicoViewJFrame.colocarTotal(total);
            }            
        }        
        
    void executar(){
        servicoViewJFrame =  new ServicoViewJFrame();
        listaServicos     = new ArrayList<Servico>();
        servicoViewJFrame.addInserirListener(new InserirServicoListener());
        servicoViewJFrame.addLimparListener(new LimparServicosListener());
        servicoViewJFrame.addTotalListener(new TotalServicosListener());
        servicoViewJFrame.setVisible(true);
    }
    
}
