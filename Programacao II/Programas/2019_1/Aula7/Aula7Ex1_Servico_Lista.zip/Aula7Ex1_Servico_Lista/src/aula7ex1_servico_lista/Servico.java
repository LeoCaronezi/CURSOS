/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula7ex1_servico_lista;

/**
 *
 * @author alunoti
 */
public class Servico {
    private String nomeServico;
    private double precoServico;

    public Servico(String nomeServico, double precoServico) {
        this.nomeServico = nomeServico;
        this.precoServico = precoServico;
    }

    public String getNomeServico() {
        return nomeServico;
    }

    public double getPrecoServico() {
        return precoServico;
    }

    @Override
    public String toString() {
        return (nomeServico + " - R$ " + precoServico );
    }   
}
