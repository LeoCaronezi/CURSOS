package aula5_ex1;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class VeiculoView {
    private JFrame veiculoJframe;
    private JLabel codigoJlabel;
    private JTextField codigoJtext;
    private JLabel velocidadeJlabel;
    private JTextField velocidadeJtext;
    private JLabel distanciaJlabel;
    private JTextField distanciaJtext;
    private JButton calcularJbutton;
    private JLabel tempoJlabel;
    private JTextField tempoJtext;

    public VeiculoView() {
        veiculoJframe = new JFrame("Dados do veiculo");
        veiculoJframe.setSize(200, 200);
        veiculoJframe.setLayout(new FlowLayout());
        veiculoJframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        codigoJlabel = new JLabel("Codigo: ");
        codigoJtext = new JTextField(10);
        velocidadeJlabel = new JLabel("Velocidade: ");
        velocidadeJtext = new JTextField(10);
        distanciaJlabel = new JLabel("Distancia: ");
        distanciaJtext = new JTextField(10);
        calcularJbutton = new JButton("Calcular");
        tempoJlabel = new JLabel("Tempo: ");
        tempoJtext = new JTextField(10);
        veiculoJframe.add(codigoJlabel);
        veiculoJframe.add(codigoJtext);
        veiculoJframe.add(velocidadeJlabel);
        veiculoJframe.add(velocidadeJtext);
        veiculoJframe.add(distanciaJlabel);
        veiculoJframe.add(distanciaJtext);
        veiculoJframe.add(calcularJbutton);
        veiculoJframe.add(tempoJlabel);
        veiculoJframe.add(tempoJtext);
        veiculoJframe.setVisible(true);
        
        
        
       
    }
    public void inicializaOuvinte(ActionListener listener){
        calcularJbutton.addActionListener(listener);
    }
    
    public double retornaVelocidade(){
        return Double.parseDouble(velocidadeJtext.getText());
    }
    
    public double retornaDistancia(){
        return Double.parseDouble(distanciaJtext.getText());
    }
    
    public String retornaCodigo(){
        return codigoJtext.getText();
    }
    
    public void mostraTotal(double total){
        tempoJtext.setText(Double.toString(total));
    }
}
