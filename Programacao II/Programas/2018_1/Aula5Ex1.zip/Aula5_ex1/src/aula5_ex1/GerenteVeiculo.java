package aula5_ex1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GerenteVeiculo {
    private Veiculo veiculoGerente;
    private VeiculoView veiculoView;
    
    private class VeiculoListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            String codigo = veiculoView.retornaCodigo();
            double velocidade = veiculoView.retornaVelocidade();
            double distancia = veiculoView.retornaDistancia();
            veiculoGerente = new Veiculo(codigo, velocidade, distancia);
            double total = veiculoGerente.totalTempo();
            veiculoView.mostraTotal(total);
        }
       
    }
    
    public void executar(){
       veiculoView = new VeiculoView();
       VeiculoListener l = new VeiculoListener();
       veiculoView.inicializaOuvinte(l);
        
    }
    
}
