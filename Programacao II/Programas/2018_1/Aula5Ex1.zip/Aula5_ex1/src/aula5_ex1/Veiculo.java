/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5_ex1;

public class Veiculo {
    private String codigoVeiculo;
    private double velocidadeVeiculo;
    private double distanciaPercorrida;

    public Veiculo(String codigoVeiculo, 
            double velocidadeVeiculo, 
            double distanciaPercorrida) {
        this.codigoVeiculo = codigoVeiculo;
        this.velocidadeVeiculo = velocidadeVeiculo;
        this.distanciaPercorrida = distanciaPercorrida;
    }
    public double totalTempo(){
        double tempo = distanciaPercorrida / velocidadeVeiculo;
        return tempo;
    }
    
    
}
