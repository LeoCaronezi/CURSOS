
package aula06_ex1;


public class Pessoa {
    protected String nomePessoa;
    protected int idade;
    protected String nomeArq = "C:\\Users\\alunoti\\Desktop\\AulaPII\\funcionarios.txt";

    public Pessoa(String nomePessoa, int idade) {
        this.nomePessoa = nomePessoa;
        this.idade = idade;
    }
    
    public Pessoa(){
        
    }
    public void salvar(){
        
    }
    
}
