
package aula06_ex1;


public class Aula06_ex1 {

   
    public static void main(String[] args) {
        Empresa e = new Empresa();
        e.iniciarEmpresa();
    }
    
}
