package aula8ex1_paint;

import aula8ex1_paint.view.MainPaintView;

public class Aula8Ex1_Paint {

    public static void main(String[] args) {
        MainPaintView mpv = new MainPaintView();
        mpv.setVisible(true);
    }    
}
