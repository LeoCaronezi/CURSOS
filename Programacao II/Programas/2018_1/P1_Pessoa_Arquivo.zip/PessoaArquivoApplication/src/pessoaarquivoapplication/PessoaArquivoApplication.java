/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoaarquivoapplication;

/**
 *
 * @author aluno
 */
public class PessoaArquivoApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Criar objeto da classe pessoa
        Pessoa p1 = new Pessoa("Batman",125,"C:\\Users\\Public\\Documents\\ArqPessoa.txt");
        Pessoa p2 = new Pessoa("Ras'al Gull",350,"C:\\Users\\Public\\Documents\\ArqPessoa.txt");
        Pessoa p3 = new Pessoa("Louis Lante",35,"C:\\Users\\Public\\Documents\\ArqPessoa.txt");
        
        
        p1.savePessoa();
        p2.savePessoa();
        p3.savePessoa();
              
        
    }
    
}
