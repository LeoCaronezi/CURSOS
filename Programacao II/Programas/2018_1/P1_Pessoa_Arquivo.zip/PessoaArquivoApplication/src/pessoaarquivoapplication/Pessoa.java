/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoaarquivoapplication;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aluno
 */
public class Pessoa {
    //Atributo nome da pessoa
    private String nomePessoa  = "Qualquer";
    //Atributo idade da pessoa
    private int    idadePessoa = 0;
    //Nome do arquivo que sera escrito com os dados
    private String nomeArq = null;
    
    //Construtor da Classe sem parametros
    public Pessoa(){
        // Nao faz nada. Serve para criar objeto vazio
    }
    //Construtor para inicializar os valores dos atributos
    public Pessoa(String nome, int idade, String arq){
        nomePessoa = nome;
        idadePessoa = idade;
        this.nomeArq = arq;     
    }

    public void savePessoa(){
      try{
        boolean noFinal = true;
        FileWriter fw = new FileWriter(nomeArq,noFinal);
            String linha = "Pessoa:" + nomePessoa + "  Idade:"+idadePessoa +"\r\n";
            fw.write(linha);
        fw.close();          
        
      }catch(IOException ex){
          System.out.println("Erro de arquivo "+ex);
      }
        
    }

    
}
