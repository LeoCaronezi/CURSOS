/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import aula8ex1_paint.view.MainPaintView;
import aula8ex1_paint.view.TelaJPanel;

/**
 *
 * @author Usuário
 */
public class MotorCarro implements Runnable{
    private TelaJPanel tela;
            
    public MotorCarro(TelaJPanel tela) {
        this.tela = tela;
    }
  
    @Override
    public void run() {        
        try{
            while(true){
                while(tela.isMotorLigado()){ 
                    tela.atualizaDeltaCarros();
                    tela.repaint();
                    Thread.sleep(100);
                }
            }            
        }catch(InterruptedException ex){
            
        }
        
        
        
        
        
    }
    
    
    
    
}
