/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoid.localizacao.celeborn;

/**
 *
 * @author andre
 */
public class LivroMapasArquivo extends LivroMapas{

    public LivroMapasArquivo(String nomeLivro, String donoLivro) {
        super(nomeLivro, donoLivro);
    }

    
    
    
    @Override
    public void salvaLivro() {

    }

    @Override
    public void carregaLivro() {

    }
    
}
