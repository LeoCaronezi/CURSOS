/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoid.itens.gandwise;

import zoid.itens.gandwise.FabricaItens;

/**
 *
 * @author andre
 */
public class FabricaItensArquivo extends FabricaItens{

    public FabricaItensArquivo(String nomeArq) {
        super(nomeArq);
    }

    @Override
    public void salvaFabrica() {
        
    }

    @Override
    public void carregaFabrica() {
        
    }
    
    
    
    
}
