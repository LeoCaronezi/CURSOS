/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoid.elros;

/**
 *
 * @author andre
 */
public class GerenteZoidV1 extends GerenteZoid{

    @Override
    public void iniciarZoid() {
        System.out.println("Zoid V1 - Iniciando");
    }
    
    
    
}
