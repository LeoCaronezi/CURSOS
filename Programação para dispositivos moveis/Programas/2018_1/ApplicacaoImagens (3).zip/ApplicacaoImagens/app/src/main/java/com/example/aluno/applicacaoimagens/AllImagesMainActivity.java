package com.example.aluno.applicacaoimagens;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class AllImagesMainActivity extends AppCompatActivity {
    private ImageView img1;
    private ImageView img2;
    private ImageView img3;
    private TextView status;
    private Intent mainIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_images_main);
        InicializarComponentes();
        InicializarListeners();
    }
    private void InicializarComponentes(){
        img1 = findViewById(R.id.imageViewIMG1);
        img2 = findViewById(R.id.imageViewIMG2);
        img3 = findViewById(R.id.imageViewIMG3);
        status = findViewById(R.id.IDtextViewStatus);
        mainIntent = new Intent(this,MainImagesActivity.class);
    }
    private void InicializarListeners(){
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                status.setText("ERROU!!!!");
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                status.setText("Tenta de novo otario!!!!");
            }
        });
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(mainIntent);
            }
        });
    }

}
