package com.example.aluno.applicacaoimagens;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainImagesActivity extends AppCompatActivity {
    private Button bImg1;
    private Button bImg2;
    private Button bImg3;

    private ImageView imgMain;

    private Intent allImagesIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_images);
        this.inicializarComponentes();
        this.inicilizarListeners();
    }
    private void inicilizarListeners(){
        bImg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgMain.setImageResource(R.drawable.image1);
            }
        });

        bImg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgMain.setImageResource(R.drawable.image2);
            }
        });

        bImg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgMain.setImageResource(R.drawable.image3);
            }
        });

        imgMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(allImagesIntent);
            }
        });

    }
    private void inicializarComponentes(){
        bImg1   = (Button)   findViewById(R.id.IDbuttonIMG1);
        bImg2   = (Button)   findViewById(R.id.IDbuttonIMG2);
        bImg3   = (Button)   findViewById(R.id.IDbuttonIMG3);
        imgMain = (ImageView)findViewById(R.id.IDimageViewMAIN);
        allImagesIntent = new Intent(this,AllImagesMainActivity.class);
    }




}
