package br.com.amm.aula1_app1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PainelPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_painel_principal);
        final TextView resultado = findViewById(R.id.textViewResult);
        final TextView num1 = (TextView)findViewById(R.id.editTextNum1);
        final TextView num2 = (TextView)findViewById(R.id.editTextNum2);
        final Button b = (Button)findViewById(R.id.buttonSoma);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double n1 = Double.parseDouble(num1.getText().toString());
                double n2 = Double.parseDouble(num2.getText().toString());
                double soma = n1 + n2;
                resultado.setText(Double.toString(soma));

            }
        });


    }
}
