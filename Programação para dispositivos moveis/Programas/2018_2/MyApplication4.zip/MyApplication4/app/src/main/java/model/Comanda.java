package model;

public class Comanda {
    private String bebidaCom;
    private Double precoBebida;

    @Override
    public String toString() {
        return
                "Bebida: " + bebidaCom +
                ", R$ " + precoBebida ;

    }

    public Comanda(String bebidaCom, Double precoBebida) {
        this.bebidaCom = bebidaCom;
        this.precoBebida = precoBebida;
    }

    public String getBebidaCom() {
        return bebidaCom;
    }

    public void setBebidaCom(String bebidaCom) {
        this.bebidaCom = bebidaCom;
    }

    public Double getPrecoBebida() {
        return precoBebida;
    }

    public void setPrecoBebida(Double precoBebida) {
        this.precoBebida = precoBebida;
    }
}
