package com.example.alunoti.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import model.Comanda;


public class MainActivity extends AppCompatActivity {
    private EditText bebidaEditText;
    private EditText precoEditText;
    private Button   buttonInsere;
    private Button   buttonConta;
    private ArrayList<Comanda> lista;
    private ListView listView;
    private ArrayAdapter<Comanda> listaAdap;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bebidaEditText = findViewById(R.id.ID1bebidaEditText);
        precoEditText = findViewById(R.id.ID1precoEditText);
        buttonInsere = findViewById(R.id.ID1buttonInsere);
        buttonConta = findViewById(R.id.ID1buttonConta);
        lista = new ArrayList<Comanda>();
        listView = findViewById(R.id.ID1lista);
        listaAdap = new ArrayAdapter<Comanda>(this,android.R.layout.simple_expandable_list_item_1,
                lista);
        listView.setAdapter(listaAdap);
        buttonInsere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = bebidaEditText.getText().toString();
                double d = Double.parseDouble(precoEditText.getText().toString());

                Comanda c = new Comanda(s,d);
                lista.add(c);
                listaAdap.notifyDataSetChanged();

            }
        });

    }
}
