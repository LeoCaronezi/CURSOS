package com.example.professor.aula4ex1listacomanda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.sql.DatabaseMetaData;
import java.util.ArrayList;

public class ComandaActivity extends AppCompatActivity {

    private EditText comidaEditText;
    private EditText bebidaEditText;
    private EditText precoComEditText;
    private EditText precoBebEditText;
    private TextView resultTextView;
    private Button acrescentaButton;
    private Button   fecharContaButton;

    /// 1 parte da Lista
    private ListView comandaListView;

    /// Usado para colocar os itens da conta
    /// 2 parte da Lista
    private ArrayList<ItemConta> listaConta;
    /// 3 parte da lista
    private ArrayAdapter<ItemConta> listaContaAdapter;

    /// Usado para abrir segunda Activity
    private Intent totalConta;
    /// Variavel auxiliar pra calcular o total
    private double totalGasto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comanda);
        /// "Materializar os objetos da view
        comidaEditText    = (EditText) findViewById(R.id.ID1COMIDAeditText);
        bebidaEditText    = (EditText) findViewById(R.id.ID1BEBeditText3);
        precoComEditText  = (EditText) findViewById(R.id.ID1PRECOCOMeditText2);
        precoBebEditText  = (EditText) findViewById(R.id.ID1PRECOBEBeditText4);
        resultTextView    = (TextView) findViewById(R.id.ID1TOTALtextView6);
        acrescentaButton  = (Button)   findViewById(R.id.ID1ACRESCENTAbutton);
        fecharContaButton = (Button)   findViewById(R.id.ID1CONTAbutton2);

        ////////////////////// USANDO A LIST VIEW ///////////////
        /// 1 parte da Lista
        comandaListView   = (ListView) findViewById(R.id.ID1LISTAListView);
        /// Criar objeto da lista ///
        /// 2 parte da Lista
        listaConta = new ArrayList<ItemConta>();
        // 3 parte da Lista                             /// PADRAO////
        listaContaAdapter = new ArrayAdapter<ItemConta>(this,android.R.layout.simple_list_item_1,
                                                        listaConta);
        /// Conectando a parte visual
        comandaListView.setAdapter(listaContaAdapter);
        ////////////////////////////////////////////////////////////////////


        /// Criar objeto para criar nova activity ////
        totalConta = new Intent(this,ContaActivity.class);

        acrescentaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /// Meu codigo de acrescentar na lista vem aqui
                //// Obter Dados digitados ;;;
                String comida = comidaEditText.getText().toString();
                String bebida = bebidaEditText.getText().toString();
                double precoComida = Double.parseDouble( precoComEditText.getText().toString() );
                double precoBebida = Double.parseDouble( precoBebEditText.getText().toString() );

                /// Construir um objeto do tipo Item Conta com os dados
                ItemConta item = new ItemConta(comida,precoComida,bebida,precoBebida);
                // Colocar o objeto na lista da conta
                listaConta.add(item);
                listaContaAdapter.notifyDataSetChanged();

                totalGasto += (precoBebida + precoComida);

                resultTextView.setText("[" + totalGasto + "]");
            }
        });
        fecharContaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Codigo que vai abrir a segunda activity
                Bundle pacote = new Bundle();
                pacote.putDouble("TOTAL",totalGasto);
                totalConta.putExtras(pacote);

                startActivity(totalConta);
            }
        });




    }
}
