package com.example.professor.aula4ex1listacomanda;

public class ItemConta {
    private String nomeComida;
    private double precoComida;
    private String nomeBebida;
    private double precoBebida;

    public ItemConta(String nomeComida, double precoComida, String nomeBebida, double precoBebida) {
        this.nomeComida = nomeComida;
        this.precoComida = precoComida;
        this.nomeBebida = nomeBebida;
        this.precoBebida = precoBebida;
    }


    @Override
    public String toString() {
        return nomeComida +" | "+nomeBebida+ "   R$ "+(precoComida+precoBebida) ;
    }
}
