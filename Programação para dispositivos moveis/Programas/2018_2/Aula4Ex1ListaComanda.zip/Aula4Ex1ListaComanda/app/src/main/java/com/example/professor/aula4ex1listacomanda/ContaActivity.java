package com.example.professor.aula4ex1listacomanda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class ContaActivity extends AppCompatActivity {

        private TextView resultadoTextView;
        private TextView resutl2TextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conta);
        resultadoTextView = (TextView) findViewById(R.id.ID2RESULT1textView7);
        resutl2TextView   = (TextView) findViewById(R.id.ID2RESULT2textView9);

        Intent it = getIntent();
        Bundle pacote = it.getExtras();

        double total = pacote.getDouble("TOTAL");

        resultadoTextView.setText(""+total);
        resutl2TextView.setText(""+ (1.1*total));
    }





}
