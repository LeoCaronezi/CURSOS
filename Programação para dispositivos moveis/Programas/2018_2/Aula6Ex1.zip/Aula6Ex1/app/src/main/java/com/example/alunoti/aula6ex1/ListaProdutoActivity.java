package com.example.alunoti.aula6ex1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaProdutoActivity extends AppCompatActivity {
    //Declarar variaveis da view
    private EditText nomeEditText;
    private EditText precoEditText;
    private Button   insereButton;

    private ListView               listViewProduto;
    private ArrayList<Produto>     listaProduto;
    private ArrayAdapter<Produto>  listaAdapter;

    private Intent                  detalheIntent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_produto);
        inicializaComponentes();
        inicializaListeners();
    }
    /// Inicializar os componentes visuais
    public void inicializaComponentes(){
        nomeEditText    = (EditText) findViewById(R.id.ID1PRODUTOeditText);
        precoEditText   = (EditText) findViewById(R.id.ID1PRECOeditText2);
        insereButton    = (Button)   findViewById(R.id.ID1INSEREbutton2);

         // Materializar o ListView
        listViewProduto = (ListView) findViewById(R.id.ID1LISTAListView);
        // Criar o Array em Java
        listaProduto    = new ArrayList<Produto>();
        // Criar o Adaptador com a Lista em Java
        listaAdapter   = new ArrayAdapter<Produto>(this,android.R.layout.simple_expandable_list_item_1,
                                                   listaProduto);
        // Ligar o ListView com o Adaptador
        listViewProduto.setAdapter(listaAdapter);


        detalheIntent = new Intent(this,ProdutoDetalheActivity.class);
    }
    /// Inicializar os Listeners
    public void inicializaListeners(){
        insereButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nomeEditText.getText().toString();
                String precostr = precoEditText.getText().toString();
                double preco = Double.parseDouble(precostr);
                Produto produto = new Produto(nome,preco);

                listaProduto.add(produto);
                listaAdapter.notifyDataSetChanged();
            }
        });

        listViewProduto.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Produto p = (Produto) parent.getItemAtPosition(position);
                //Criei um pacote de envio
                Bundle bundle = new Bundle();
                //Coloquei os dados com ROTULO
                bundle.putString("PRODUTO",p.getNomeProduto());
                bundle.putDouble("PRECO",p.getPrecoProduto());
                // Coloquei na Intent
                detalheIntent.putExtras(bundle);
                ///Disparar a nova Activity
                startActivity(detalheIntent);
            }
        });


    }





}
