package com.example.alunoti.aula6ex1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class ProdutoDetalheActivity extends AppCompatActivity {
    //Declarar variaveis da view
    private EditText produtoEditText;
    private EditText precoEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto_detalhe);
        inicializaComponentes();
        carregaDados();
    }
    public void inicializaComponentes(){
        produtoEditText = (EditText) findViewById(R.id.ID2PRODUTOeditText);
        precoEditText   = (EditText) findViewById(R.id.ID2PRECOeditText2);
    }

    public void carregaDados(){
        Intent it = getIntent();
        Bundle bundle = it.getExtras();
        String nome  = bundle.getString("PRODUTO");
        double preco = bundle.getDouble("PRECO");
        produtoEditText.setText(nome);
        precoEditText.setText(""+preco);
    }


}
