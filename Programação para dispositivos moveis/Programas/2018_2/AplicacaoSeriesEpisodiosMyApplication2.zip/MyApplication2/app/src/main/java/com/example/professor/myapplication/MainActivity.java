package com.example.professor.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText tituloEditText;
    private EditText nrEpEditText;
    private EditText duracaoEditText;
    private EditText categoriaEditText;

    private Button   enviaButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /// Inicializar Variaveis
        tituloEditText    = (EditText) findViewById(R.id.ID1TituloEditText);
        enviaButton       = (Button)   findViewById(R.id.ID1EnviaButton);
        nrEpEditText      = (EditText) findViewById(R.id.ID1NumEpEeditText);
        duracaoEditText   = (EditText) findViewById(R.id.ID1DuracaoEditText);
        categoriaEditText = (EditText) findViewById(R.id.ID1CatEditText);

        // Inicializar Listeners
        enviaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Envia os dados
                comandoEnviar();
            }
        });
    }

    /// metodo para enviar os dados
    protected void comandoEnviar(){
        //// Criar Intent
        Intent mostraIntent = new Intent(this,
                                          MostraSerieActivity.class);
        /// Criar "Pacote" pra ler os dados
        Bundle pacote = new Bundle();
        /// Colocar Par "Key-Valor" no Bundle
        pacote.putString("TITULO",tituloEditText.getText().toString());
        pacote.putString("CATEGORIA",categoriaEditText.getText().toString());

        int nrEp = Integer.parseInt(nrEpEditText.getText().toString());
        double duracao = Double.parseDouble(duracaoEditText.getText().toString());

        pacote.putInt("NR_EPISODIOS",nrEp);
        pacote.putDouble("DURACAO",duracao);

        /// Colocar pacote na Intent
        mostraIntent.putExtras(pacote);
        //// Inicializar Segunda Activity
        startActivity(mostraIntent);
    }


}
