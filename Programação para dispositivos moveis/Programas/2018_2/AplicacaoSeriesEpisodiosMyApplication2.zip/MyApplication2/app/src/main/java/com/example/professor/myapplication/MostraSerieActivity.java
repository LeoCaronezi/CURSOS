package com.example.professor.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MostraSerieActivity extends AppCompatActivity {
    private TextView tituloTextView;
    private TextView resultTextView;
    private TextView categoriaTextView;

    private Button   voltaButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostra_serie);

        /// inicializar Variaveis
        tituloTextView    = (TextView) findViewById(R.id.ID2TituloTtextView);
        resultTextView    = (TextView) findViewById(R.id.ID2ResultadoTextView);
        categoriaTextView = (TextView) findViewById(R.id.ID2CatTextView);
        voltaButton       = (Button)   findViewById(R.id.ID2VoltaButton);

        // Receber Dados
        receberOrigem();
        //// inicializar Listeners
        voltaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comandoVolta();
            }
        });
    }

    protected void receberOrigem(){
        /// Obter a Intent que iniciou a Activity
        Intent intentOrigem = getIntent();
        /// Obter o pacote
        Bundle pacoteOrigem = intentOrigem.getExtras();
        /// Pegar os dados dentro do pacote
        String tituloOrigem = pacoteOrigem.getString("TITULO");
        String catOrigem    = pacoteOrigem.getString("CATEGORIA");
        int nrEpisodios = pacoteOrigem.getInt("NR_EPISODIOS");
        double duracao  = pacoteOrigem.getDouble("DURACAO");

        // Colocar os dados na tela
        tituloTextView.setText(tituloOrigem);
        resultTextView.setText("["+nrEpisodios*duracao+"]");
        categoriaTextView.setText(catOrigem);
    }

    protected void comandoVolta(){
        //// Criar Intent
        Intent mainIntent = new Intent(this,MainActivity.class);
        //// Inicializar Activity
        startActivity(mainIntent);
    }




}
