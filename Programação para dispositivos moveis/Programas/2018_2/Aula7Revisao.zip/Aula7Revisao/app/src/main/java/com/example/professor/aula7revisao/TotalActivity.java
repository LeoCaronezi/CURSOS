package com.example.professor.aula7revisao;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class TotalActivity extends AppCompatActivity {
    private EditText nrItensEditText;
    private EditText totalEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total);
        inicializarComponentes();
        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        int   nritens = b.getInt("NRITENS");
        double  total = b.getDouble("TOTAL");
        nrItensEditText.setText(" "+nritens);
        totalEditText.setText(" "+total);
    }
    public  void inicializarComponentes(){
        nrItensEditText = (EditText) findViewById(R.id.ID2_NRITENSeditText3);
        totalEditText   = (EditText) findViewById(R.id.ID2_TOTALeditText4);
    }
}
