package com.example.professor.aula7revisao;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Iterator;

public class ProdutoActivity extends AppCompatActivity {
    // Declaracao dos componentes que vao ser usados no Layout Visual
    private EditText produtoEditText;
    private EditText precoEditText;
    private Button   insereListaButton;
    private Button   insereBancoButton;
    private Button   leBancoButton;
    private Button   mostraTotalButton;

    // Tres componentes para tratamento de lista
    private ListView               listaProdutoListView;
    private ArrayList<Produto>     listaProdutoArrayList;
    private ArrayAdapter<Produto>  listaProdutoArrayAdapter;

    private Intent              totalActivityIntent;
    private GerenciadorDB       gerenciadorDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto);
        inicializarComponentes();
        inicializarListeners();
        gerenciadorDB       = new GerenciadorDB(this);
        totalActivityIntent = new Intent(this,TotalActivity.class);
    }
    public  void inicializarComponentes(){
        produtoEditText    = (EditText) findViewById(R.id.ID1PRODUTOeditText);
        precoEditText      = (EditText) findViewById(R.id.ID1PRECOeditText2);
        insereListaButton  = (Button)   findViewById(R.id.ID1_INSERELISTAbutton);
        insereBancoButton  = (Button)   findViewById(R.id.ID1_INSEREBANCObutton2);
        leBancoButton      = (Button)   findViewById(R.id.ID1_LERBANCO_button3);
        mostraTotalButton  = (Button)   findViewById(R.id.ID1_TOTAL_button4);

        listaProdutoListView      = (ListView)findViewById(R.id.ID1_LISTA_ListView);
        listaProdutoArrayList     = new ArrayList<Produto>();
        listaProdutoArrayAdapter  = new ArrayAdapter<Produto>(this,android.R.layout.simple_list_item_1,
                                                              listaProdutoArrayList);
        listaProdutoListView.setAdapter(listaProdutoArrayAdapter);
    }
    public void inicializarListeners(){
        insereListaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Produto p = obterProdutoDigitado();
                listaProdutoArrayList.add(p);
                listaProdutoArrayAdapter.notifyDataSetChanged();
            }
        });
        insereBancoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Produto p = obterProdutoDigitado();
                gerenciadorDB.insereBanco(p);
            }
        });
        leBancoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listaProdutoArrayAdapter.clear();
                listaProdutoArrayList.clear();
                gerenciadorDB.leBanco(listaProdutoArrayList);
            }
        });
        mostraTotalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispararActivity();
            }
        });
        listaProdutoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Produto p = (Produto) parent.getItemAtPosition(position);
                colocarProduto(p);
            }
        });

    }
    public Produto obterProdutoDigitado(){
        String nome     = produtoEditText.getText().toString();
        String precostr = precoEditText.getText().toString();
        double preco    = Double.parseDouble(precostr);
        Produto p = new Produto(nome,preco);
        return p;
    }
    public void colocarProduto(Produto p){
        produtoEditText.setText(p.getNomeProduto());
        precoEditText.setText("" + p.getPrecoProduto());
    }
    public void dispararActivity(){
        int    totalItens = 0;
        double totalPreco = 0.0;
        Iterator<Produto> iterator = listaProdutoArrayList.iterator();
        while (iterator.hasNext()){
            Produto p = (Produto) iterator.next();
            totalItens++;
            totalPreco += p.getPrecoProduto();
        }
        Bundle b = new Bundle();
        b.putInt("NRITENS",totalItens);
        b.putDouble("TOTAL",totalPreco);
        totalActivityIntent.putExtras(b);
        startActivity(totalActivityIntent);
    }

}
