package com.example.professor.aula7revisao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.strictmode.SqliteObjectLeakedViolation;

import java.util.ArrayList;

public class GerenciadorDB extends SQLiteOpenHelper {

    public GerenciadorDB(Context context) {
        super(context, "COMPRASDB", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE PRODUTOTB(NOME TEXT, PRECO REAL)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insereBanco(Produto p){
        SQLiteDatabase db = getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("NOME",p.getNomeProduto());
            contentValues.put("PRECO",p.getPrecoProduto());
            db.insert("PRODUTOTB",null,contentValues);
        db.close();
    }
    public void leBanco(ArrayList<Produto> lista){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        String[] colunas = {"NOME","PRECO"};
        cursor = db.query("PRODUTOTB",colunas,null,null,null,null,null);
        /// Apontar o cursor para a 1 posicao do resultado //
        /// Retorna TRUE se existe pelo menos um registro //
        boolean existeDados = cursor.moveToFirst();
        while (existeDados){
            // Obtem os dados das colunas correspondentes (String colunas)
            String nome  = cursor.getString(0);
            double preco = cursor.getDouble(1);
            Produto p = new Produto(nome,preco);
            lista.add(p);
            // Move o cursor para o proximo registro mas retorna
            // falso se nao houver mais registros
            existeDados = cursor.moveToNext();
        };
        db.close();
    }

}
