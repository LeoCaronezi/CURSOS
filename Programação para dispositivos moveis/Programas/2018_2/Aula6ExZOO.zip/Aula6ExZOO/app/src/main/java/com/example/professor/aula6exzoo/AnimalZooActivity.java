package com.example.professor.aula6exzoo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class AnimalZooActivity extends AppCompatActivity {

    private EditText animalEditText;
    private EditText pesoEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_zoo);

        animalEditText = (EditText) findViewById(R.id.ID2ANIMALeditText3);
        pesoEditText   = (EditText) findViewById(R.id.ID2PESOeditText4);

        Intent i = getIntent();
        Bundle b = i.getExtras();

        String nome = b.getString("NOME");
        double peso = b.getDouble("PESO");

        animalEditText.setText(nome);
        pesoEditText.setText(peso + " gramas");

    }
}
