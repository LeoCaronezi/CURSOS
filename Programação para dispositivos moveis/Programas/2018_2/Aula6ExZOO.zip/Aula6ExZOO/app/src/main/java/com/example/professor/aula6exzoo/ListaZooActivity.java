package com.example.professor.aula6exzoo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaZooActivity extends AppCompatActivity {
    // Declarar Atributos
    private EditText animalEditText;
    private EditText pesoEditText;
    private Button   insereButton;

    // Declaracao da Lista
    private ListView              zooListView;
    private ArrayList<Animal>     zooLista;
    private ArrayAdapter<Animal>  zooAdapter;

    private Intent                animalIntent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_zoo);
        /// Inicializar Atributos
        inicializarComponentes();
        // Inicializar Listeners
        inicializarListeners();
    }

    public void inicializarComponentes(){
        animalEditText = (EditText) findViewById(R.id.ID1ANIMLAeditText);
        pesoEditText   = (EditText) findViewById(R.id.ID1PESOeditText2);
        insereButton   = (Button)   findViewById(R.id.ID1INSEREbutton);

        zooListView    = (ListView) findViewById(R.id.ID1LISTAListView);
        zooLista       =  new ArrayList<Animal>();
        zooAdapter     =  new ArrayAdapter<Animal>(this, android.R.layout.simple_list_item_1,
                                                   zooLista); // Conexao com a Lista de objetos
        zooListView.setAdapter(zooAdapter);

        animalIntent = new Intent(this,AnimalZooActivity.class);
    }

    public void inicializarListeners(){
        /// Listener do Botao
        insereButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /// Peguei valores digitados
                String nome     = animalEditText.getText().toString();
                String pesostr  = pesoEditText.getText().toString();
                double peso     = Double.parseDouble(pesostr);
                // Criar objeto da classe Animal
                Animal a = new Animal(nome,peso);
                zooLista.add(a);
                zooAdapter.notifyDataSetChanged();
            }
        });
        //// Listen do Item da Lista
        zooListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //// Obter Objeto clicado
                Animal x = (Animal) parent.getItemAtPosition(position);


                System.out.println(x);
                   String nome  = x.getNomeAnimal();
                   double peso  = x.getPesoAnimal();
                   Bundle bundle = new Bundle();
                   bundle.putString("NOME",nome);
                   bundle.putDouble("PESO",peso);
                   animalIntent.putExtras(bundle);
                startActivity(animalIntent);
            }
        });



    }


}
