package com.example.professor.aula6exzoo;

public class Animal {
    private String nomeAnimal;
    private double pesoAnimal;

    public Animal(String nomeAnimal, double pesoAnimal) {
        this.nomeAnimal = nomeAnimal;
        this.pesoAnimal = pesoAnimal;
    }

    public String getNomeAnimal() {
        return nomeAnimal;
    }

    public double getPesoAnimal() {
        return pesoAnimal;
    }

    @Override
    public String toString() {
        return nomeAnimal + " - peso:" + pesoAnimal ;
    }
}
