package com.example.alunoti.aula4exprodutoarray;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ProdutoActivity extends AppCompatActivity {
    private TextView nomeTextView;
    private TextView precoTextView;
    private  TextView quantidade;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto);
        nomeTextView    = findViewById(R.id.ID2_NOMEtextView4);
        precoTextView   = findViewById(R.id.ID2PRECOtextView5);
        quantidade = findViewById(R.id.ID2QDEtextView6);


        Intent inicial = getIntent();
        Bundle b = inicial.getExtras();

        String nome = b.getString("NOME");
        double preco = b.getDouble("PRECO");
        int   qde    = b.getInt("QDE");

        nomeTextView.setText(nome);
        precoTextView.setText("R$ "+preco);
        quantidade.setText("Quantidade: "+qde);






    }
}
