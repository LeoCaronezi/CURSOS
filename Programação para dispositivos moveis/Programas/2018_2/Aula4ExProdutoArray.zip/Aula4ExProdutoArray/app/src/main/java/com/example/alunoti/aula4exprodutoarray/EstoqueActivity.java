package com.example.alunoti.aula4exprodutoarray;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Iterator;

public class EstoqueActivity extends AppCompatActivity {
    private EditText nomeEditText;
    private EditText precoEditText;
    private EditText qdeEditText;
    private Button   armezenarButton;
    private Button   procurarButton;
    private ArrayList<Produto> listaEstoque;
    private Intent intentProduto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estoque);

        nomeEditText  = (EditText) findViewById(R.id.ID1_NomeProdEditText);
        precoEditText = (EditText) findViewById(R.id.ID1_PrecoEditText2);
        qdeEditText   = (EditText) findViewById(R.id.ID1_QDEeditText3);
        armezenarButton = (Button) findViewById(R.id.ID1_ARMAZENAR_button);
        procurarButton =  (Button) findViewById(R.id.ID1_LISTAR_button);
        listaEstoque   = new ArrayList<Produto>();
        intentProduto = new Intent(this,ProdutoActivity.class);



        armezenarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeproduto = nomeEditText.getText().toString();
                double preco       = Double.parseDouble(precoEditText.getText().toString());
                int    qde         = Integer.parseInt(qdeEditText.getText().toString());
                Produto p = new Produto(nomeproduto,preco,qde);
                listaEstoque.add(p);
            }
        });

        procurarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /// Pegar nome to produto a ser pesquisado
                String nomeproduto = nomeEditText.getText().toString();
                /// Obeter um ITERADOR  para varrer a lista
                Iterator<Produto> it = listaEstoque.iterator();
                /// Inicializar parameros da busca
                boolean achou = false;
                Produto p = new Produto("NAO ACHADO",0,0);
                /// Varrer a lista ate achar ou fim da lista //
                while (it.hasNext() && achou==false){
                    p = (Produto) it.next();
                    if(p.getNomeProduto().equals(nomeproduto)){
                        achou = true;
                    }
                }
                /// colocar valroes achados
                double preco       = 0;
                int    qde         = 0;
                if(achou){
                    preco       = p.getPrecoProduto();
                    qde         = p.getQdeProduto();
                }


                Bundle b = new Bundle();
                b.putString("NOME",nomeproduto);
                b.putDouble("PRECO",preco);
                b.putInt("QDE",qde);

                intentProduto.putExtras(b);

                startActivity(intentProduto);
            }
        });



    }
}
