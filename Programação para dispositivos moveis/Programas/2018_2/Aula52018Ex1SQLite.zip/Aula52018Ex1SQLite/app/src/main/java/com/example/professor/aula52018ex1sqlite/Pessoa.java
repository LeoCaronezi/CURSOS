package com.example.professor.aula52018ex1sqlite;

public class Pessoa {
    private String nomePessoa;
    private int    idadePessoa;

    public Pessoa(String nomePessoa, int idadePessoa) {
        this.nomePessoa = nomePessoa;
        this.idadePessoa = idadePessoa;
    }


    public String getNomePessoa() {
        return nomePessoa;
    }

    public int    getIdadePessoa() {
        return idadePessoa;
    }

    @Override
    public String toString() {
        return  nomePessoa + " - " + idadePessoa + " anos";
    }
}
