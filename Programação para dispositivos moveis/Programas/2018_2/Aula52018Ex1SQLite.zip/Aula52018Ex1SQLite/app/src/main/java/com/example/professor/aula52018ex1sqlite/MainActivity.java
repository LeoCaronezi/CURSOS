package com.example.professor.aula52018ex1sqlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText nomeEditText;
    private EditText idadeEditText;
    private Button   insereButton;
    private Button   leBancoButton;
    private Button   limpaButton;

    // Santa Trindade da ListView ////
    private ListView              pessoaListView; // Parte Visual
    private ArrayList<Pessoa>     listaPessoa;    // Parte Logica (modelo)
    private ArrayAdapter<Pessoa>  pessoaArrayAdapter; // Conector ou Controlador
    //////////////////////////////////

    //Referencia para banco de dados
    private GerenciadorDB gerenciadorDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inicializaComponentes();
        inicializaListeners();
        //Inicializar Banco de Dados
        gerenciadorDB  = new GerenciadorDB(this);
    }
    // Pra ficar Organizado - Inicializar os componentes aqui //
    public void inicializaComponentes(){
        nomeEditText   = (EditText) findViewById(R.id.ID1NOMEeditText);
        idadeEditText  = (EditText) findViewById(R.id.ID1IDADEeditText2);
        insereButton   = (Button)   findViewById(R.id.ID1INSEREbutton);
        leBancoButton  = (Button)   findViewById(R.id.ID1LEBANCObutton2);
        limpaButton    = (Button)   findViewById(R.id.ID1LIMPAbutton3);

        /// Inicializacao para a ListView ///
        pessoaListView     = (ListView) findViewById(R.id.ID1LISTAListView); //
        listaPessoa        = new ArrayList<Pessoa>();    //
        pessoaArrayAdapter = new ArrayAdapter<Pessoa>(this,android.R.layout.simple_list_item_1,
                                                      listaPessoa);
        pessoaListView.setAdapter(pessoaArrayAdapter);
        /////////////////////////////////////
    }
    // Outro para os Listeners (Para responder acoes)//
    public void inicializaListeners(){
        insereButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Codigo de inserir
                String nome = nomeEditText.getText().toString();
                String idadestr = idadeEditText.getText().toString();
                int    idade    = Integer.parseInt(idadestr);
                Pessoa p = new Pessoa(nome,idade);
                try {
                    gerenciadorDB.inserePessoaBanco(p);
                }catch (Exception e){
                    System.out.println("Erro "+e);
                }

            }
        });
        leBancoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Codigo para ler o banco
                try{
                    gerenciadorDB.leListaBanco(listaPessoa);
                }catch (Exception e){
                    System.out.println("Erro "+e);
                }

                pessoaArrayAdapter.notifyDataSetChanged();
            }
        });
        limpaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pessoaArrayAdapter.clear();
                listaPessoa.clear();
                pessoaArrayAdapter.notifyDataSetChanged();
            }
        });

    }




}
