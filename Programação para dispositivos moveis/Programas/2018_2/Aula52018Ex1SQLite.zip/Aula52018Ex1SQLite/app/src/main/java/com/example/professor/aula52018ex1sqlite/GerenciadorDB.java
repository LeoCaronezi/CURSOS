package com.example.professor.aula52018ex1sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.constraint.solver.ArrayLinkedVariables;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class GerenciadorDB extends SQLiteOpenHelper {
    private static final int VERSAO_BANCO = 1;
    private static final String  NOME_BANCO = "PESSOADB";
    private static final String  NOME_TABELA = "PESSOA_TB";
    private static final String CRIACAO_TABELA = "CREATE TABLE PESSOA_TB(NOME  TEXT," +
                                                          " IDADE INTEGER);";
    public GerenciadorDB(Context context) {
        super(context, NOME_BANCO, null, VERSAO_BANCO);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CRIACAO_TABELA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void inserePessoaBanco(Pessoa p) throws Exception{
        //Codigo para inserir no banco
        SQLiteDatabase db = getWritableDatabase();
        ContentValues registro = new ContentValues();
        registro.put("NOME",  p.getNomePessoa());
        registro.put("IDADE", p.getIdadePessoa());
        db.insert(NOME_TABELA,null,registro);
        db.close();
    }
    public void leListaBanco(ArrayList<Pessoa> lista) throws Exception{
        //Codigo para ler a tabela do banco
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        String[] coluna = new String[2];
        coluna[0] = "NOME";
        coluna[1] = "IDADE";
        cursor = db.query(NOME_TABELA,coluna,null,null,null,null,null);
        if(cursor!=null) {
            /// Importante SEMPRE COLOCAR O CURSOR NA PRIMEIRA POSICAO ANTES
            cursor.moveToFirst();
            while (cursor != null) {
                String nome = cursor.getString(0);
                int idade = cursor.getInt(1);
                Pessoa p = new Pessoa(nome, idade);
                lista.add(p);
                // MOVER PARA  PROXIMA
                cursor.moveToNext();
            }
        }
        db.close();
    }
}
