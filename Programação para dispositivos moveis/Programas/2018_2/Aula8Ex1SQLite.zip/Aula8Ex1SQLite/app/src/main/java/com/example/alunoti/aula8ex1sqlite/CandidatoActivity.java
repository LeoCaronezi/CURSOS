package com.example.alunoti.aula8ex1sqlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class CandidatoActivity extends AppCompatActivity {
    private EditText candidatoEditText;
    private EditText votosEditText;
    private Button   insereButton;
    private Button   leBancoButton;

    private ListView                  listaCandidatoListView;
    private ArrayList<Candidato>      listaCandidato;
    private ArrayAdapter<Candidato>   listaCandidatoArrayAdapter;

    private ControladorBanco  controladorBanco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_candidato);
        //Chamar Metodos de Inicializacao
        inicializaComponentes();
        inicializacaoListers();
        //TODO Criar o objeto Controlador de Banco de dados
        controladorBanco = new ControladorBanco(getBaseContext());
    }
    public void inicializaComponentes(){
        //TODO Inicializacao de componentes
        candidatoEditText = (EditText) findViewById(R.id.ID1NOMEeditText);
        votosEditText     = (EditText) findViewById(R.id.ID1VOTOSeditText2);
        insereButton      = (Button)   findViewById(R.id.ID1INSEREbutton);
        leBancoButton     = (Button)   findViewById(R.id.ID1LEBANCObutton);

        listaCandidatoListView = (ListView) findViewById(R.id.ID1LISTAListView);
        listaCandidato         = new ArrayList<Candidato>();
        listaCandidatoArrayAdapter = new ArrayAdapter<Candidato>(this,android.R.layout.simple_expandable_list_item_1,
                                                                 listaCandidato);
        listaCandidatoListView.setAdapter(listaCandidatoArrayAdapter);
    }
    public void inicializacaoListers(){
        //TODO Inicializaco de Eventos
        insereButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //inserir no banco de dados
                String nome    = candidatoEditText.getText().toString();
                String votostr = votosEditText.getText().toString();
                int    votos   = Integer.parseInt(votostr);
                Candidato c = new Candidato(nome,votos);
                controladorBanco.insereBanco(c);
            }
        });
        leBancoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ler do banco de dados e por na lista
                listaCandidatoArrayAdapter.clear();
                listaCandidato.clear();
                controladorBanco.leBanco(listaCandidato);
                listaCandidatoArrayAdapter.notifyDataSetChanged();
            }
        });



    }

}
