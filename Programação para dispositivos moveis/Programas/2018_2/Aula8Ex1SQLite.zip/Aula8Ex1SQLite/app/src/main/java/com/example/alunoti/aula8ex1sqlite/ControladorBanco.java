package com.example.alunoti.aula8ex1sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class ControladorBanco extends SQLiteOpenHelper {
    //TODO Codigo do controlador

    // Alterar parametros do construtor para so receber o contexto
    public ControladorBanco(Context context) {
        super(context,"ELEICAODB2", null, 2);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE CANDIDATOTB(NOME  TEXT, " +
                                            "VOTOS INTEGER)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
         //TODO codigo em caso de atualizacao do banco
    }

    //// insere no banco de dados
    public void insereBanco(Candidato candidato){
        SQLiteDatabase  db = getWritableDatabase();

        ContentValues registro = new ContentValues();
        registro.put("NOME",candidato.getNomeCandidato());
        registro.put("VOTOS",candidato.getVotosCandidato());

        db.insert("CANDIDATOTB",null,registro);
        db.close();
    }
    ///// Le do banco de dados ////
    void leBanco(ArrayList<Candidato> lista){
        // Obter Banco de Dados para leitura
        SQLiteDatabase  db = getReadableDatabase();
        // Declarar cursor
        Cursor cursor;
        /// Array com a lista de colunas do resultado
        String coluna[] = new String[2];
        coluna[0] = "NOME";
        coluna[1] = "VOTOS";
        // Executar consulta
        try {
            cursor = db.query("CANDIDATOTB", coluna, null, null, null, null, null, null);
            if(cursor!=null){
                cursor.moveToFirst();
                while (cursor!=null){
                    String nome  = cursor.getString(0);
                    int    votos = cursor.getInt(1);
                    Candidato c = new Candidato(nome,votos);
                    lista.add(c);
                    cursor.moveToNext();
                }
            }
        }catch (Exception e){
            System.out.println("Erro "+e);
        }
        db.close();
    }




}
