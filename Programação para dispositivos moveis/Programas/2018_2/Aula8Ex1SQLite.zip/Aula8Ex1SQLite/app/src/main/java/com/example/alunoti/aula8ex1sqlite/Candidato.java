package com.example.alunoti.aula8ex1sqlite;
// Minha classe de dados ou MODELO
public class Candidato {
    private String nomeCandidato;
    private int    votosCandidato;

    public Candidato(String nomeCandidato, int votosCandidato) {
        this.nomeCandidato = nomeCandidato;
        this.votosCandidato = votosCandidato;
    }
    public String getNomeCandidato() {
        return nomeCandidato;
    }
    public int getVotosCandidato() {
        return votosCandidato;
    }
    @Override
    public String toString() {
        return "NOME:" + nomeCandidato ;
    }
}
