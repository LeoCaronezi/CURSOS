package com.example.alunoti.aula8ex1sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class OutroControladorDB extends SQLiteOpenHelper {
    public OutroControladorDB(Context context) {
        super(context,"BANCODB2",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
