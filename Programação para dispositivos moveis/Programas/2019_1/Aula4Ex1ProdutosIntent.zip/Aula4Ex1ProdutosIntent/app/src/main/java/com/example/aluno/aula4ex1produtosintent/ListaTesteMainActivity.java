package com.example.aluno.aula4ex1produtosintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ListaTesteMainActivity extends AppCompatActivity {
    private TextView listaTextView;
    private TextView totalTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_teste_main);
        listaTextView = (TextView) findViewById(R.id.ID3_LISTAtextView4);
        totalTextView = (TextView) findViewById(R.id.ID3TOTALtextView6);

        Intent it = getIntent();
        Bundle trouxa = it.getExtras();

        String lista = trouxa.getString("LISTA");
        double total = trouxa.getDouble("TOTAL");

        listaTextView.setText(lista);
        totalTextView.setText("R$ "+total);
    }
}
