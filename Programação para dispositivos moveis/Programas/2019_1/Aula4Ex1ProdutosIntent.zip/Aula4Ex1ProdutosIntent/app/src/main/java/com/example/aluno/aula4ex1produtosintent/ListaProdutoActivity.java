package com.example.aluno.aula4ex1produtosintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ListaProdutoActivity extends AppCompatActivity {
    private TextView listaTextView;
    private TextView totalTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_produto);

        listaTextView = (TextView) findViewById(R.id.ID2_LISTAtextView4);
        totalTextView = (TextView) findViewById(R.id.ID2_TOTALtextView6);

        Intent it = getIntent();
        Bundle trouxa = it.getExtras();

        String lista = trouxa.getString("LISTA");
        
        double total = trouxa.getDouble("TOTAL");

        listaTextView.setText(lista);

        totalTextView.setText("R$ "+total);

    }
}
