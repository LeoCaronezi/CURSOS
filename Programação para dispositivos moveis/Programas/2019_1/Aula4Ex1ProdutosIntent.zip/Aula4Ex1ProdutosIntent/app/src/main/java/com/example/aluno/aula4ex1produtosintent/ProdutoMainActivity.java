package com.example.aluno.aula4ex1produtosintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ProdutoMainActivity extends AppCompatActivity {
    private EditText produtoEditText;
    private EditText precoEditText;
    private Button   addButton;
    private TextView totalTextView;
    private Button   mostrarListaButton;

    private double totalPreco = 0;
    private String listaProdutos = "Lista:" + '\n';

    private Intent listaIntent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto_main);
        inicializarComponentes();
        inicializarListeners();
    }
    protected void inicializarComponentes(){
        produtoEditText      = (EditText) findViewById(R.id.ID1_NOMEeditText);
        precoEditText        = (EditText) findViewById(R.id.ID1_PRECOeditText2);;
        addButton            = (Button)   findViewById(R.id.ID1_ADDbutton);
        totalTextView        = (TextView) findViewById(R.id.ID1_TOTALtextView4);
        mostrarListaButton   = (Button)   findViewById(R.id.ID1_MOSTRARbutton2);

        //listaIntent = new Intent(this,ListaTesteMainActivity.class);
        listaIntent = new Intent(this,ListaProdutoActivity.class);
    }
    protected void inicializarListeners(){

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obter Valores Digitados
                String produto = produtoEditText.getText().toString();
                double preco   = Double.parseDouble(precoEditText.getText().toString());
                // Adicionar preco //
                totalPreco += preco;
                // mostrar total
                totalTextView.setText("R$ "+totalPreco);
                // Adicionar produto na lista
                listaProdutos += (" = > " + produto + '\n');
            }
        });
        /////////////////
        mostrarListaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle trouxa = new Bundle();
                trouxa.putString("LISTA",listaProdutos);
                trouxa.putDouble("TOTAL",totalPreco);
                listaIntent.putExtras(trouxa);
                startActivity(listaIntent);
            }
        });



        /*
        mostrarListaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle b = new Bundle();
                b.putString("LISTA",listaProdutos);
                b.putDouble("TOTAL",totalPreco);
                listaIntent.putExtras(b);
                startActivity(listaIntent);
            }
        });  */

    }

}
