package com.example.aluno.aula5ex1_animais;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class AnimaisMainActivity extends AppCompatActivity {
    private EditText nomeAnimalEditText;
    private EditText precoAnimalEditText;
    private EditText idadeAnimalEditText;
    private EditText totalPrecoEditText;
    private Button   totalButton;

    private ListView             listaListView;
    private ArrayList<String>    listaAnimais;
    private ArrayAdapter<String> listaArrayAdapter;

    private double total=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animais_main);
        inicializaComponentes();
        inicializaListener();
    }
    protected void inicializaComponentes(){
        nomeAnimalEditText   = (EditText) findViewById(R.id.ID1_ANIMALeditText);
        precoAnimalEditText  = (EditText) findViewById(R.id.ID1_PRECOeditText2);
        idadeAnimalEditText  = (EditText) findViewById(R.id.ID1_IDADEeditText3);
        totalPrecoEditText   = (EditText) findViewById(R.id.ID1_TOTALeditText4);
        totalButton          =  (Button)  findViewById(R.id.ID1_ADICIONARbutton);

        listaListView        = (ListView) findViewById(R.id.ID1_LISTAListView);
        listaAnimais         = new ArrayList<String>();
        listaArrayAdapter    = new ArrayAdapter<String>(this,
                                          android.R.layout.simple_expandable_list_item_1,
                                   listaAnimais);
        listaListView.setAdapter(listaArrayAdapter);

    }
    protected void inicializaListener(){
        totalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /////
                double digitado = Double.parseDouble(precoAnimalEditText.getText().toString());
                total += digitado;
                totalPrecoEditText.setText(Double.toString(total));

                String nome = nomeAnimalEditText.getText().toString();
                listaAnimais.add(nome);
                listaArrayAdapter.notifyDataSetChanged();

            }
        });
    }

}
