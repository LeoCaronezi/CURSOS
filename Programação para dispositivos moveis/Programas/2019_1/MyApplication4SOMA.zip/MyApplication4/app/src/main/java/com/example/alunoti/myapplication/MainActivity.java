package com.example.alunoti.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText  num1EditText;
    private EditText  num2EditText;
    private Button    somarButton;
    private TextView  resultadoTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1EditText       = (EditText) findViewById(R.id.NUM1editText);
        num2EditText       = (EditText) findViewById(R.id.NUM2editText2);
        somarButton        = (Button)   findViewById(R.id.SOMARbutton);
        resultadoTextView  = (TextView) findViewById(R.id.RESULTADOtextView3);
       /// Inicializar tratamento do evento de click do botao ///
        somarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO Passo 1 - obter numero digitado na caixa 1
                String num1txt = num1EditText.getText().toString();
                double num1 = Double.parseDouble(num1txt)  ;

                //TODO Passo 2 - obter numero digitado na caixa 2
                String num2txt = num2EditText.getText().toString();
                double num2 = Double.parseDouble(num2txt)  ;

                //TODO Passo 3 - Somar numeros
                double soma = num1 + num2;

                //TODO Passo 4 - Colocar soma dos numeros no texto do resultado
                //forma 1:  resultadoTextView.setText(Double.toString(soma));
                resultadoTextView.setText("resultado = " + soma);
            }
        });




    }
}
