package com.example.aula8ex1_remediossqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class GerenciadorBancoRemedios extends SQLiteOpenHelper {

        private final static int     VERSAO_BANCO = 1;
        private final static String  NOME_BANCO = "REMEDIODB";
        private final static String  TABELA1    = "TB_REMEDIO";

        private String CREATE_TABELA1 = "CREATE TABLE "+
                                                TABELA1 +
                                        "(REMEDIO TEXT," +
                                         "PRECO   REAL);";

    public GerenciadorBancoRemedios(Context context) {
        super(context, NOME_BANCO, null, VERSAO_BANCO);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABELA1);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insereRemedio(Remedio remedio){
        try {
            SQLiteDatabase db = getWritableDatabase();
                ContentValues registro = new ContentValues();
                registro.put("REMEDIO",remedio.getNomeRemedio());
                registro.put("PRECO",remedio.getPrecoRemedio());
                db.insert(TABELA1,null,registro);
            db.close();
        }catch (Exception e){
            System.out.print("Problema de insercao "+e);
        }
    }
    public void recuperaRemedios(ArrayList<Remedio> lista){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor;
        String[] coluna = new String[2];
        coluna[0] = "REMEDIO";
        coluna[1] = "PRECO";
        boolean proximo = false;
        cursor = db.query(TABELA1,coluna,null,null,null,null,null);
        if(cursor == null){
            System.out.println("Erro de banco");
        }else{
            proximo = cursor.moveToFirst();
        }
        while (proximo){
            String nome  = cursor.getString(0);
            double preco = cursor.getDouble(1);
            Remedio r = new Remedio(nome,preco);
            lista.add(r);
            proximo = cursor.moveToNext();
        }
        db.close();
    }
}
