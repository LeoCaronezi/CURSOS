package com.example.aula8ex1_remediossqlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText nomeRemedioEditText;
    private EditText precoRemedioEditText;
    private Button   insereButton;
    private Button   limparButton;
    private Button   carregarButton;

    private ListView              listaRemediosListView;
    private ArrayList<Remedio>    listaRemedios;
    private ArrayAdapter<Remedio> listaRemediosRemedioArrayAdapter;

    private GerenciadorBancoRemedios gerenciadorBancoRemedios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gerenciadorBancoRemedios = new GerenciadorBancoRemedios(this);
        inicializaComponentes();
        inicializaListeners();
    }
    protected void inicializaComponentes(){

        nomeRemedioEditText    = (EditText) findViewById(R.id.ID1_NOMEREMeditText);
        precoRemedioEditText   = (EditText) findViewById(R.id.ID1_PRECOeditText2);
        insereButton           = (Button)   findViewById(R.id.ID1_INSERIRbutton);
        limparButton           = (Button)   findViewById(R.id.ID1_LIMPARbutton3);
        carregarButton         = (Button)   findViewById(R.id.ID1_CARREGARbutton2);

        listaRemediosListView  = (ListView) findViewById(R.id.ID1_LISTAListView);
        listaRemedios          = new ArrayList<Remedio>();
        listaRemediosRemedioArrayAdapter = new ArrayAdapter<Remedio>(this,
                                      android.R.layout.simple_list_item_1,
                                      listaRemedios);
        listaRemediosListView.setAdapter(listaRemediosRemedioArrayAdapter);
    }
    protected void inicializaListeners(){
        ////-----------------------////
        insereButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO /--- AQUI IRA O CODIGO ////
                String nome  = nomeRemedioEditText.getText().toString();
                double preco = Double.parseDouble(precoRemedioEditText.getText().toString());
                Remedio r = new Remedio(nome,preco);
                listaRemedios.add(r);
                gerenciadorBancoRemedios.insereRemedio(r);
                listaRemediosRemedioArrayAdapter.notifyDataSetChanged();
            }
        });
        ///---------------------*///
        limparButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO codigo do limpar
                listaRemedios.clear();
                listaRemediosRemedioArrayAdapter.notifyDataSetChanged();
            }
        });
        ///------------------------///
        carregarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO codigo do carregar do banco
                listaRemedios.clear();
                gerenciadorBancoRemedios.recuperaRemedios(listaRemedios);
                listaRemediosRemedioArrayAdapter.notifyDataSetChanged();
            }
        });


    }


}
