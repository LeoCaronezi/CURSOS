package com.example.aula8ex1_remediossqlite;

public class Remedio {
        private String nomeRemedio;
        private double precoRemedio;

    public Remedio(String nomeRemedio, double precoRemedio) {
        this.nomeRemedio = nomeRemedio;
        this.precoRemedio = precoRemedio;
    }
    public String getNomeRemedio() {
        return nomeRemedio;
    }
    public double getPrecoRemedio() {
        return precoRemedio;
    }
    @Override
    public String toString() {
        return "Remedio: - " + nomeRemedio;
    }
}
