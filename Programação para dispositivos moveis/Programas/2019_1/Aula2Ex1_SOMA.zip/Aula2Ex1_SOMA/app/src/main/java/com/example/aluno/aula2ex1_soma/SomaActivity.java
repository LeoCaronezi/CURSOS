package com.example.aluno.aula2ex1_soma;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SomaActivity extends AppCompatActivity {
    private EditText num1EditText;
    private EditText num2EditText;
    private Button   somarButton;
    private EditText resultadoEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soma);

        num1EditText        = findViewById(R.id.ID_NUM1editText);
        num2EditText        = findViewById(R.id.ID_NUM2editText2) ;
        somarButton         = findViewById(R.id.ID_SOMARbutton);
        resultadoEditText   = findViewById(R.id.ID_RESULTADOeditText3) ;
        somarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Passo 1 - Obter os numeros Digitados
                double n1 = Double.parseDouble(num1EditText.getText().toString());

                String n2String = num2EditText.getText().toString();
                double n2 = Double.parseDouble(n2String);

                double soma = n1 + n2;

                //resultadoEditText.setText(Double.toString(soma));
                resultadoEditText.setText("Res:"+soma);


            }
        });

    }
}
