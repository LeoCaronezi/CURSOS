package aula1pxi_ex2;

import javax.swing.JOptionPane;



public class Aula1PXI_EX2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nomeProduto;
        String qdeProdutoStr;
        String precoProdutoStr;
        
        nomeProduto     = JOptionPane.showInputDialog("Entre com o nome do produto:");
        qdeProdutoStr   = JOptionPane.showInputDialog("Entre com a quantidade do produto");
        precoProdutoStr = JOptionPane.showInputDialog("Entre com o preco do produto:");
        
        int    qdeProduto     = Integer.parseInt(qdeProdutoStr);
        double precoProduto   = Double.parseDouble(precoProdutoStr);
        
        JOptionPane.showMessageDialog(null, "Eu comprei " + qdeProduto + " de "
                + nomeProduto + " por " + (qdeProduto*precoProduto));        
    }  
}
