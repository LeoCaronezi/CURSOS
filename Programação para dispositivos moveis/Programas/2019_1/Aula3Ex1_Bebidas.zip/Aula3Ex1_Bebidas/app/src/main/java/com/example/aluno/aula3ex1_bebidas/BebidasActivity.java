package com.example.aluno.aula3ex1_bebidas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class BebidasActivity extends AppCompatActivity {
    private EditText nomeBebidaEditText;
    private EditText precoBebidaEditText;
    private EditText nrBebidasEditText;
    private Button   adicionarBebidaButton;
    private EditText totalGastoEditText;
    private EditText totalGarrafasEditText;

    private double   totalGasto = 0;
    private int      totalGarrafas = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebidas);

        nomeBebidaEditText     = findViewById(R.id.ID1_NOMEBEBIeditText);
        precoBebidaEditText    = findViewById(R.id.ID1_PRECOeditText2);
        nrBebidasEditText      = findViewById(R.id.ID1_NRGARRAeditText3);
        adicionarBebidaButton  = findViewById(R.id.ID1_ADICIONARbutton);
        totalGastoEditText     = findViewById(R.id.ID1_GASTOTOTeditText4);
        totalGarrafasEditText  = findViewById(R.id.ID1_TOTGAReditText5);

        adicionarBebidaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /// Codigo de tratamento do click do botao
                //1 - Obter os valores digitados
                String precoStr = precoBebidaEditText.getText().toString();
                double preco = Double.parseDouble(precoStr);

                String nrGarStr = nrBebidasEditText.getText().toString();
                int nrGar       = Integer.parseInt(nrGarStr);
                // 2 - Calcular os totais
                double total  = nrGar * preco;
                totalGasto    = totalGasto + total;
                totalGarrafas = totalGarrafas + nrGar;
                // 3 - Colocar os totais na aplicacao
                totalGastoEditText.setText(Double.toString(totalGasto));
                totalGarrafasEditText.setText(Integer.toString(totalGarrafas));
            }
        });



    }
}
