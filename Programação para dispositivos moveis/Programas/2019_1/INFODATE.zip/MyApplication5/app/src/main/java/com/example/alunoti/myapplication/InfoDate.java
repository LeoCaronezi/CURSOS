package com.example.alunoti.myapplication;

public class InfoDate {
    private String nomeDate,
                   sexoDate,
                   descricaoDate,
                   buscaDate;
    private int    idadeDate;
    private double alturaDate,
                   pesoDate;

    @Override
    public String toString() {
        return nomeDate + " - " + idadeDate;
    }

    public InfoDate(String nomeDate, String sexoDate, String descricaoDate, String buscaDate, int idadeDate, double alturaDate, double pesoDate) {
        this.nomeDate = nomeDate;
        this.sexoDate = sexoDate;
        this.descricaoDate = descricaoDate;
        this.buscaDate = buscaDate;
        this.idadeDate = idadeDate;
        this.alturaDate = alturaDate;
        this.pesoDate = pesoDate;
    }

    public String getNomeDate() {
        return nomeDate;
    }

    public void setNomeDate(String nomeDate) {
        this.nomeDate = nomeDate;
    }

    public String getSexoDate() {
        return sexoDate;
    }

    public void setSexoDate(String sexoDate) {
        this.sexoDate = sexoDate;
    }

    public String getDescricaoDate() {
        return descricaoDate;
    }

    public void setDescricaoDate(String descricaoDate) {
        this.descricaoDate = descricaoDate;
    }

    public String getBuscaDate() {
        return buscaDate;
    }

    public void setBuscaDate(String buscaDate) {
        this.buscaDate = buscaDate;
    }

    public int getIdadeDate() {
        return idadeDate;
    }

    public void setIdadeDate(int idadeDate) {
        this.idadeDate = idadeDate;
    }

    public double getAlturaDate() {
        return alturaDate;
    }

    public void setAlturaDate(double alturaDate) {
        this.alturaDate = alturaDate;
    }

    public double getPesoDate() {
        return pesoDate;
    }

    public void setPesoDate(double pesoDate) {
        this.pesoDate = pesoDate;
    }
}
