package com.example.alunoti.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.BitSet;

public class MainActivity extends AppCompatActivity {

    private EditText nomeEditText;
    private EditText sexoEditText;
    private EditText idadeEditText;
    private EditText alturaEditText;
    private EditText pesoEditText;
    private EditText descricaoEditText;

    private CheckBox homemCB;
    private CheckBox mulherCB;
    private CheckBox outrosCB;

    private SGBD gerenciadorBanco;

    private Button insereButton;
    private Button excluiButton;
    private Button alteraButton;

    private ListView dateListView;
    private ArrayList<InfoDate> arrayList;
    private ArrayAdapter<InfoDate> arrayAdapter;

    private Intent toSubIntent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializaComponentes();
        inicializaListener();

        gerenciadorBanco.retornaDate(arrayList);
        arrayAdapter.notifyDataSetChanged();
    }


    protected void inicializaComponentes() {
        nomeEditText = (EditText) findViewById(R.id.ID1_nomeET);
        sexoEditText = (EditText) findViewById(R.id.ID1_sexoET);
        idadeEditText = (EditText) findViewById(R.id.ID1_idadeET);
        alturaEditText = (EditText) findViewById(R.id.ID1_alturaET);
        pesoEditText = (EditText) findViewById(R.id.ID1_pesoET);
        descricaoEditText = (EditText) findViewById(R.id.ID1_descricaoEditText);

        insereButton = (Button) findViewById(R.id.ID1_insereButton);
        excluiButton = (Button) findViewById(R.id.ID1_excluiButton);
        alteraButton = (Button) findViewById(R.id.ID1_alterarButton);

        toSubIntent = new Intent(this, SubActivity.class);

        gerenciadorBanco = new SGBD(this);

        dateListView = findViewById(R.id.ID1_dateListView);
        arrayList = new ArrayList<InfoDate>();
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_expandable_list_item_1, arrayList);
        dateListView.setAdapter(arrayAdapter);

        homemCB = findViewById(R.id.ID1_homemCB);
        mulherCB = findViewById(R.id.ID1_mulherCB);
        outrosCB = findViewById(R.id.ID1_outrosCB);




    }

    protected void inicializaListener() {
        insereButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nomeEditText.getText().toString();
                String sexo = sexoEditText.getText().toString();
                int idade = Integer.parseInt(idadeEditText.getText().toString());
                double altura = Double.parseDouble(alturaEditText.getText().toString());
                double peso = Double.parseDouble(pesoEditText.getText().toString());
                String descricao = descricaoEditText.getText().toString();
                String busca = "";
                if (homemCB.isChecked()) {
                    busca = busca + "H";
                }
                if (mulherCB.isChecked()) {
                    busca = busca + "M";
                }
                if (outrosCB.isChecked()) {
                    busca = busca + "O";
                }

                InfoDate infodate = new InfoDate(nome, sexo, descricao, busca, idade, altura, peso);
                gerenciadorBanco.insereDate(infodate);
                arrayList.add(infodate);
                arrayAdapter.notifyDataSetChanged();
                ///limpaCampos();
            }
        });
        excluiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nomeEditText.getText().toString();
                String sexo = sexoEditText.getText().toString();
                int idade = Integer.parseInt(idadeEditText.getText().toString());
                double altura = Double.parseDouble(alturaEditText.getText().toString());
                double peso = Double.parseDouble(pesoEditText.getText().toString());
                String descricao = descricaoEditText.getText().toString();
                String busca = "";
                if (homemCB.isChecked()) {
                    busca = busca + "H";
                }
                if (mulherCB.isChecked()) {
                    busca = busca + "M";
                }
                if (outrosCB.isChecked()) {
                    busca = busca + "O";
                }

                InfoDate infodate = new InfoDate(nome, sexo, descricao, busca, idade, altura, peso);
                gerenciadorBanco.apagaDate(infodate);
                arrayList.clear();
                gerenciadorBanco.retornaDate(arrayList);
                arrayAdapter.notifyDataSetChanged();

            }
        });
        alteraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        dateListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
    }

    protected void limpaCampos() {
        nomeEditText.setText("");
        sexoEditText.setText("");
        idadeEditText.setText("");
        alturaEditText.setText("");
        pesoEditText.setText("");
        descricaoEditText.setText("");
    }
}