package com.example.alunoti.myapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;

import java.util.ArrayList;


public class SGBD extends SQLiteOpenHelper {
    private final static short VERSION = 1;
    private final static String NOMEBANCO = "DATEDB";
    private final static String TABELA ="TB_DATE";
    private final static String CRIAR_TABELA = "CREATE TABLE " + TABELA +
            "(NOMEDATE              TEXT"+
            ",SEXODATE              TEXT"+
            ",IDADEDATE             INTEGER"+
            ",BUSCADATE             TEXT"+
            ",ALTURADATE            REAL"+
            ",PESODATE              REAL"+
            ",DESCRICAODATE         TEXT"+
            ");";

    public SGBD(Context context){
        super(context, NOMEBANCO, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CRIAR_TABELA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //:^)
    }

    public void insereDate(InfoDate infodate){
        SQLiteDatabase db   = getWritableDatabase();
        ContentValues  reg  = new ContentValues();

        reg.put("NOMEDATE", infodate.getNomeDate());
        reg.put("SEXODATE", infodate.getSexoDate());
        reg.put("IDADEDATE", infodate.getIdadeDate());
        reg.put("BUSCADATE", infodate.getBuscaDate());
        reg.put("ALTURADATE", infodate.getAlturaDate());
        reg.put("PESODATE", infodate.getPesoDate());
        reg.put("DESCRICAODATE", infodate.getDescricaoDate());

        db.insert(TABELA, null, reg);
        db.close();
    }

    public void apagaDate(InfoDate infoDate){
        SQLiteDatabase db = getWritableDatabase();
        String where = "NOMEDATE = ? ";
        String[] selecao = new String[1];
        selecao[0] = infoDate.getNomeDate();
        db.delete(TABELA,where,selecao);
    }

    public ArrayList<InfoDate> retornaDate(ArrayList<InfoDate> lista){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor;
        String coluna [] = new String[7];
        coluna[0] = "NOMEDATE";
        coluna[1] = "SEXODATE";
        coluna[2] = "IDADEDATE";
        coluna[3] = "BUSCADATE";
        coluna[4] = "ALTURADATE";
        coluna[5] = "PESODATE";
        coluna[6] = "DESCRICAODATE";

        cursor = db.query(TABELA, coluna, null, null, null, null, null);
        boolean proximo = false;
        if (cursor == null){
            System.out.println("deu erro no banco ... pepega");
        }else{
            proximo = cursor.moveToFirst();
        }
        while (proximo){
            String nome = cursor.getString(0);
            String sexo = cursor.getString(1);
            int idade = cursor.getInt(2);
            String busca = cursor.getString(3);
            double altura = cursor.getDouble(4);
            double peso = cursor.getDouble(5);
            String descricao = cursor.getString(6);

            InfoDate infodate = new InfoDate(nome,sexo,descricao,busca,idade,altura,peso);
            lista.add(infodate);
            proximo = cursor.moveToNext();
        }
        db.close();
        return lista;
    }
    public ArrayList<InfoDate> retornaDate(){
        ArrayList<InfoDate> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor;
        String coluna [] = new String[7];
        coluna[0] = "NOMEDATE";
        coluna[1] = "SEXODATE";
        coluna[2] = "IDADEDATE";
        coluna[3] = "BUSCADATE";
        coluna[4] = "ALTURADATE";
        coluna[5] = "PESODATE";
        coluna[6] = "DESCRICAODATE";

        cursor = db.query(TABELA, coluna, null, null, null, null, null);
        boolean proximo = false;
        if (cursor == null){
            System.out.println("deu erro no banco ... pepega");
        }else{
            proximo = cursor.moveToFirst();
        }
        while (proximo){
            String nome = cursor.getString(0);
            String sexo = cursor.getString(1);
            int idade = cursor.getInt(2);
            String busca = cursor.getString(3);
            double altura = cursor.getDouble(4);
            double peso = cursor.getDouble(5);
            String descricao = cursor.getString(6);

            InfoDate infodate = new InfoDate(nome,sexo,descricao,busca,idade,altura,peso);
            lista.add(infodate);
            proximo = cursor.moveToNext();
        }
        db.close();
        return lista;
    }
}
