/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoid.avatar.aragorn;

/**
 *
 * @author andre
 */
public class FabricaAvatarArquivo extends FabricaAvatar{

    public FabricaAvatarArquivo(String nomeArq) {
        super(nomeArq);
    }

    @Override
    public void salvaFabrica() {
        
    }

    @Override
    public void carregaFabrica() {
        
    }
    
    
    
    
}
