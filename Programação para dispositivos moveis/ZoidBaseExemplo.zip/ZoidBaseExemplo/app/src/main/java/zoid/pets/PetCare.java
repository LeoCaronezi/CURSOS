/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoid.pets;

/**
 *
 * @author andre
 */
public class PetCare {
    private AvatarPet pet;
    private String ArqPet;

    public PetCare(AvatarPet pet, String ArqPet) {
        this.pet = pet;
        this.ArqPet = ArqPet;
    }
        
    
    public void salvaPet() {

    }

    
    public void carregaPet() {

    }
    
}
